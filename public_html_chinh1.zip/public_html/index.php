<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// error_reporting(EALL); ini_set('display_errors','1');
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function require_admin() {
  if (empty($_SESSION['user']) || ($_SESSION['user']['role'] ?? 'user') !== 'admin') {
    header('Location: ?page=login'); exit;
  }
}

// Hàm này kiểm tra user đã login chưa (cho trang profile)
function require_login() {
  if (empty($_SESSION['user'])) {
    header('Location: ?page=login'); exit;
  }
}

$page = $_GET['page'] ?? 'home';

switch ($page) {
  // ======= Admin =======
  case 'admin_dashboard':
    require_admin();
    require __DIR__ . '/views/admin/dashboard.php';
    break;

  case 'admin_products':
    require_admin();
    require __DIR__ . '/views/admin/products.php';
    break;

  case 'admin_users':
    require_admin();
    require __DIR__ . '/views/admin/users.php';
    break;

  case 'admin_categories':
    require_admin();
    require __DIR__ . '/views/admin/categories.php';
    break;

  case 'admin_comments':
    require_admin();
    require __DIR__ . '/views/admin/comments.php';
    break;

  // ======= Front =======
  case 'product_detail':
    require_once __DIR__ . '/Controller/ProductController.php';
    $id = (int)($_GET['id'] ?? 0);
    (new ProductController())->detail($id);
    break;
    
  // ==================================
  // ===== THÊM ĐỊNH TUYẾN TIN TỨC =====
  case 'news': 
    require __DIR__ . '/views/news.php';
    break;
  // ==================================

  case 'profile':
    require_login(); // Yêu cầu đăng nhập
    require __DIR__ . '/views/profile.php';
    break;
  // ==================================

  case 'products':
    require __DIR__ . '/views/products.php';
    break;
  
  case 'cart':
    require __DIR__ . '/views/cart.php';
    break;

  case 'login':
    require __DIR__ . '/views/login.php';
    break;

  case 'register':
    require __DIR__ . '/views/register.php';
    break;

   case 'about':
    require __DIR__ . '/views/about.php';
    break;

  case 'promotions':
    require __DIR__ . '/views/promotions.php';
    break;
    
    case 'checkout':
    require __DIR__ . '/views/checkout.php';
    break;

  case 'logout':
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
      $p = session_get_cookie_params();
      setcookie(session_name(), '', time()-42000, $p["path"], $p["domain"], $p["secure"], $p["httponly"]);
    }
    session_destroy();
    header('Location: ?page=home'); exit;

  case 'home':
  default:
    require __DIR__ . '/views/home.php';
}
// Chú ý: Dòng đóng } cuối cùng đã bị xóa khỏi code gốc,
// đảm bảo bạn chỉ có một dấu } đóng switch ở cuối file.
// Code trên đã xử lý lỗi cú pháp đó.