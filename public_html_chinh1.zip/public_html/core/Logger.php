<?php
require_once __DIR__ . '/Database.php';

class Logger
{
    /**
     * Ghi log hành động vào bảng activity_logs
     * @param string $action - hành động (ví dụ: 'Thêm sản phẩm mới', 'Xóa người dùng', ...)
     * @param int|null $userId - ID người dùng (tự động lấy từ session nếu có)
     */
    public static function log(string $action, ?int $userId = null): void
    {
        try {
            $pdo = Database::get();

            // Nếu không truyền userId thì lấy từ session (nếu có)
            if (!$userId && isset($_SESSION['user']['id'])) {
                $userId = $_SESSION['user']['id'];
            }

            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action, created_at)
                VALUES (:user_id, :action, NOW())
            ");
            $stmt->execute([
                ':user_id' => $userId,
                ':action'  => $action
            ]);

        } catch (PDOException $e) {
            error_log("⚠️ Logger Error: " . $e->getMessage());
        }
    }

    /**
     * Lấy danh sách log (dùng để hiển thị trong trang admin)
     */
    public static function getAll(int $limit = 50): array
    {
        try {
            $pdo = Database::get();
            $stmt = $pdo->prepare("
                SELECT l.*, u.username 
                FROM activity_logs l
                LEFT JOIN users u ON l.user_id = u.id
                ORDER BY l.created_at DESC
                LIMIT :limit
            ");
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("⚠️ Logger::getAll error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Lấy danh sách log mới nhất (alias cho getAll)
     */
    public static function latest(int $limit = 10): array
    {
        return self::getAll($limit);
    }
}
