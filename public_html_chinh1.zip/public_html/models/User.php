<?php
// models/User.php
require_once __DIR__ . '/../core/Database.php';

class User
{
    // Tìm theo email
    public static function findByEmail(string $email): ?array {
        $pdo = Database::get();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->execute([':email' => $email]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    // Tìm theo username
    public static function findByUsername(string $username): ?array {
        $pdo = Database::get();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :u LIMIT 1");
        $stmt->execute([':u' => $username]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    // Đăng ký user mới
    public static function create(string $username, string $email, string $password): int {
        $pdo = Database::get();
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
            INSERT INTO users (username, email, password_hash, role, created_at)
            VALUES (:u, :e, :h, 'user', NOW())
        ");
        $stmt->execute([
            ':u' => $username,
            ':e' => $email,
            ':h' => $hash
        ]);
        return (int)$pdo->lastInsertId();
    }

    // Đăng nhập (alias cho verifyLogin)
    public static function login(string $emailOrUsername, string $password): ?array {
        return self::verifyLogin($emailOrUsername, $password);
    }

    // Kiểm tra login
    public static function verifyLogin(string $emailOrUsername, string $password): ?array {
        $user = filter_var($emailOrUsername, FILTER_VALIDATE_EMAIL)
              ? self::findByEmail($emailOrUsername)
              : self::findByUsername($emailOrUsername);

        if (!$user) return null;
        if (!password_verify($password, $user['password_hash'])) return null;

        return $user;
    }
}
