<?php
require_once __DIR__ . '/../core/Database.php';

class Category {
  public static function all(): array {
    $stmt = Database::get()->query("SELECT id, name, slug FROM categories ORDER BY name");
    return $stmt->fetchAll();
  }
}
