<?php
// models/Comment.php
require_once __DIR__ . '/../core/Database.php';

class Comment
{
    public static function approvedByProduct(int $productId): array {
        $pdo = Database::get();
        $sql = "
            SELECT c.id, c.content, c.rating, c.created_at,
                   COALESCE(u.username, c.guest_name) AS author
            FROM comments c
            LEFT JOIN users u ON u.id = c.user_id
            WHERE c.product_id = :pid AND c.status = 'approved'
            ORDER BY c.id DESC
            LIMIT 200
        ";
        $st = $pdo->prepare($sql);
        $st->execute([':pid' => $productId]);
        return $st->fetchAll() ?: [];
    }

    public static function create(array $data): int {
        $pdo = Database::get();
        $sql = "
            INSERT INTO comments (product_id, user_id, guest_name, guest_email, rating, content, status)
            VALUES (:product_id, :user_id, :guest_name, :guest_email, :rating, :content, 'approved')
        ";
        $st = $pdo->prepare($sql);
        $st->execute([
            ':product_id' => (int)$data['product_id'],
            ':user_id'    => isset($data['user_id']) ? (is_null($data['user_id']) ? null : (int)$data['user_id']) : null,
            ':guest_name' => $data['guest_name'] ?? null,
            ':guest_email'=> $data['guest_email'] ?? null,
            ':rating'     => (int)$data['rating'],
            ':content'    => (string)$data['content'],
        ]);
        return (int)$pdo->lastInsertId();
    }

   
     //Rating trung bình
 
    public static function avgRating(int $productId): ?float {
        $pdo = Database::get();
        $st = $pdo->prepare("
            SELECT AVG(rating) AS avg_rating
            FROM comments
            WHERE product_id = :pid AND status = 'approved' AND rating BETWEEN 1 AND 5
        ");
        $st->execute([':pid' => $productId]);
        $row = $st->fetch();
        return ($row && $row['avg_rating'] !== null) ? (float)$row['avg_rating'] : null;
    }

   
     //Đếm số bình luận cho 1 sản phẩm
  
    public static function approvedCount(int $productId): int {
        $pdo = Database::get();
        $st = $pdo->prepare("
            SELECT COUNT(*) FROM comments
            WHERE product_id = :pid AND status = 'approved'
        ");
        $st->execute([':pid' => $productId]);
        return (int)$st->fetchColumn();
    }
}
