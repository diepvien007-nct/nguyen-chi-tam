<?php
// models/Product.php
require_once __DIR__ . '/../core/Database.php';

class Product
{
    /** Lấy 1 sản phẩm theo ID (kèm tên danh mục) */
    public static function find(int $id): ?array {
        $pdo = Database::get();
        $sql = "SELECT p.*, c.name AS category_name
                FROM products p
                JOIN categories c ON c.id = p.category_id
                WHERE p.id = :id";
        $st = $pdo->prepare($sql);
        $st->execute([':id' => $id]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /** Sản phẩm nổi bật / mới (mặc định lấy theo created_at) */
    public static function featured(int $limit = 8): array {
        $pdo = Database::get();
        $sql = "SELECT p.*, c.name AS category_name
                FROM products p
                JOIN categories c ON c.id = p.category_id
                ORDER BY p.created_at DESC
                LIMIT :lim";
        $st = $pdo->prepare($sql);
        $st->bindValue(':lim', $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }

    /** Danh sách thương hiệu (distinct) để render filter */
    public static function brands(): array {
        $pdo = Database::get();
        $sql = "SELECT DISTINCT brand
                FROM products
                WHERE brand IS NOT NULL AND brand <> ''
                ORDER BY brand ASC";
        $st = $pdo->query($sql);
        return array_column($st->fetchAll(), 'brand');
    }

    /**
     * Listing + filter + sort + phân trang
     * filters:
     *  - category_id (int)
     *  - q (string) tìm theo tên/brand/slug
     *  - brand (string)
     *  - price_min (float)
     *  - price_max (float)
     *  - sort: price_asc | price_desc | name_asc | (default: created_at DESC)
     *  - page (int), per_page (int)
     */
    public static function listing(array $filters): array {
        $pdo = Database::get();

        $page    = max(1, (int)($filters['page'] ?? 1));
        $per     = max(4, min(24, (int)($filters['per_page'] ?? 8)));
        $offset  = ($page - 1) * $per;

        $where   = [];
        $params  = [];

        // Lọc theo danh mục
        if (!empty($filters['category_id'])) {
            $where[] = "p.category_id = :cid";
            $params[':cid'] = (int)$filters['category_id'];
        }

        // Từ khóa (tên / brand / slug)
        if (!empty($filters['q'])) {
            $where[] = "(p.name LIKE :q OR p.brand LIKE :q OR p.slug LIKE :q)";
            $params[':q'] = '%'.$filters['q'].'%';
        }

        // Thương hiệu
        if (!empty($filters['brand'])) {
            $where[] = "p.brand = :brand";
            $params[':brand'] = (string)$filters['brand'];
        }

        // Khoảng giá
        if (isset($filters['price_min']) && $filters['price_min'] !== '' && $filters['price_min'] !== null) {
            $where[] = "p.price >= :pmin";
            $params[':pmin'] = (float)$filters['price_min'];
        }
        if (isset($filters['price_max']) && $filters['price_max'] !== '' && $filters['price_max'] !== null) {
            $where[] = "p.price <= :pmax";
            $params[':pmax'] = (float)$filters['price_max'];
        }

        $whereSql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

        // Sort
        $order = "p.created_at DESC";
        if (!empty($filters['sort'])) {
            $order = 'p.created_at DESC';
        if (!empty($filters['sort'])) {
            switch ($filters['sort']) {
                case 'price_asc':
                    $order = 'p.price ASC';
                    break;
                case 'price_desc':
                    $order = 'p.price DESC';
                    break;
                case 'name_asc':
                    $order = 'p.name ASC';
                    break;
                default:
                    $order = 'p.created_at DESC';
                    break;
            }
        }

        }

        // Đếm tổng bản ghi
        $sqlCount = "SELECT COUNT(*) FROM products p $whereSql";
        $stCount  = $pdo->prepare($sqlCount);
        $stCount->execute($params);
        $total = (int)$stCount->fetchColumn();

        // Lấy dữ liệu trang hiện tại
        $sql = "SELECT p.*, c.name AS category_name
                FROM products p
                JOIN categories c ON c.id = p.category_id
                $whereSql
                ORDER BY $order
                LIMIT :lim OFFSET :off";
        $st = $pdo->prepare($sql);
        foreach ($params as $k => $v) {
            $st->bindValue($k, $v);
        }
        $st->bindValue(':lim', $per, PDO::PARAM_INT);
        $st->bindValue(':off', $offset, PDO::PARAM_INT);
        $st->execute();
        $rows = $st->fetchAll();

        return [
            'data'     => $rows,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $per,
            'pages'    => (int)ceil(max(1, $total) / $per),
        ];
    }

    /** Gợi ý: Lấy sản phẩm liên quan theo category (trừ chính nó) */
    public static function relatedByCategory(int $categoryId, int $exceptId, int $limit = 4): array {
        $pdo = Database::get();
        $sql = "SELECT p.*, c.name AS category_name
                FROM products p
                JOIN categories c ON c.id = p.category_id
                WHERE p.category_id = :cid AND p.id <> :eid
                ORDER BY p.created_at DESC
                LIMIT :lim";
        $st = $pdo->prepare($sql);
        $st->bindValue(':cid', $categoryId, PDO::PARAM_INT);
        $st->bindValue(':eid', $exceptId,   PDO::PARAM_INT);
        $st->bindValue(':lim', $limit,      PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }
}
