<?php
// app/config.php
if (!defined('DB_HOST')) {
    define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
    define('DB_NAME', getenv('DB_NAME') ?: 'watchshop');
    define('DB_USER', getenv('DB_USER') ?: 'codewithme');
    define('DB_PASS', getenv('DB_PASS') ?: 'Chitam287@'); // tốt hơn: lưu trong env, không commit
    define('DB_PORT', getenv('DB_PORT') ?: 3306);
    define('DB_CHARSET', getenv('DB_CHARSET') ?: 'utf8mb4');
    define('BASE_URL', getenv('BASE_URL') ?: 'https://codewithme.id.vn/');
}
