// Ẩn/hiện mật khẩu
function togglePassword(id) {
  const input = document.getElementById(id);
  if (!input) return;
  input.type = input.type === "password" ? "text" : "password";
}

// Đổi trạng thái 
function setRule(id, ok, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.toggle('text-success', ok);
  el.classList.toggle('text-danger', !ok);
  el.textContent = (ok ? '✅ ' : '❌ ') + msg;
}

// Kiểm tra mật khẩu 
function pwCheck() {
  const v = document.getElementById('password')?.value || '';
  setRule('rule-length',  v.length >= 8,               'Tối thiểu 8 ký tự');
  setRule('rule-lower',   /[a-z]/.test(v),             'Có ít nhất 1 chữ thường');
  setRule('rule-upper',   /[A-Z]/.test(v),             'Có ít nhất 1 chữ hoa');
  setRule('rule-number',  /\d/.test(v),                'Có ít nhất 1 số');
  setRule('rule-special', /[^A-Za-z0-9]/.test(v),      'Có ít nhất 1 ký tự đặc biệt');
}

// Tự khởi tạo khi trang load 
document.addEventListener('DOMContentLoaded', pwCheck);



