<?php
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Product.php';

if (!function_exists('e')) { function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); } }

// dữ liệu filter
$categories = Category::all();
$filters = [
  'category_id' => $_GET['category_id'] ?? null,
  'q'           => $_GET['q'] ?? null,
  'sort'        => $_GET['sort'] ?? null,
  'page'        => (int)($_GET['p'] ?? 1), // dùng 'p' cho phân trang, tránh đè route 'page=products'
  'per_page'    => 8,
];

$list = Product::listing($filters);
$data = $list['data'];

// nhãn sort
$sortLabel = null;
switch ($filters['sort'] ?? '') {
    case 'price_asc':
        $sortLabel = 'Sort: Price ↑';
        break;
    case 'price_desc':
        $sortLabel = 'Sort: Price ↓';
        break;
    case 'name_asc':
        $sortLabel = 'Sort: Name A → Z';
        break;
    default:
        $sortLabel = null;
}


// tên danh mục đã chọn (nếu có)
$chosenCategoryName = null;
if (!empty($filters['category_id'])) {
  foreach ($categories as $c) if ((int)$c['id'] === (int)$filters['category_id']) { $chosenCategoryName = $c['name']; break; }
}

include __DIR__ . '/partials/header.php';
?>

<!-- FILTER BAR CLEAN -->
<div class="filter-bar mb-4">
  <form method="get" id="filterForm" class="d-flex flex-wrap gap-3 align-items-end">
    <input type="hidden" name="page" value="products">

    <!-- Category -->
    <div class="filter-group">
      <label>Category</label>
      <select class="form-select filter-auto" name="category_id">
        <option value="">All</option>
        <?php foreach ($categories as $c): ?>
          <option value="<?= (int)$c['id'] ?>" <?= ($filters['category_id']==$c['id']?'selected':'') ?>>
            <?= e($c['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- Sort -->
    <div class="filter-group">
      <label>Sort</label>
      <select class="form-select filter-auto" name="sort">
        <option value="">Default</option>
        <option value="price_asc"  <?= (($filters['sort'] ?? '')==='price_asc')?'selected':'' ?>>Price ↑</option>
        <option value="price_desc" <?= (($filters['sort'] ?? '')==='price_desc')?'selected':'' ?>>Price ↓</option>
        <option value="name_asc"   <?= (($filters['sort'] ?? '')==='name_asc')?'selected':'' ?>>Name A–Z</option>
      </select>
    </div>

    <!-- Search -->
    <div class="filter-group flex-grow-1">
      <label>Search</label>
      <input type="search" class="form-control" name="q"
             placeholder="Search products..." value="<?= e($filters['q'] ?? '') ?>">
    </div>

    <!-- Buttons -->
    <div class="d-flex gap-2">
      <button class="btn btn-primary">Apply</button>
      <a class="btn btn-light border" href="<?= $base ?>?page=products">Clear</a>
    </div>
  </form>
</div>

<!-- ACTIVE FILTERS -->
<?php if ($filters['category_id'] || $filters['sort'] || ($filters['q'] ?? '')): ?>
  <div class="active-filters mb-3">
    <span class="me-2 text-muted">Active:</span>
    <?php if ($chosenCategoryName): ?>
      <span class="chip"><?= e($chosenCategoryName) ?></span>
    <?php endif; ?>
    <?php if ($sortLabel): ?>
      <span class="chip"><?= e($sortLabel) ?></span>
    <?php endif; ?>
    <?php if (!empty($filters['q'])): ?>
      <span class="chip">Search: <?= e($filters['q']) ?></span>
    <?php endif; ?>
    <a href="<?= $base ?>?page=products" class="ms-2 text-decoration-none">Clear all</a>
  </div>
<?php endif; ?>


<!-- PRODUCT GRID -->
<div class="row g-3">
  <?php if (!$data): ?>
    <div class="col-12"><div class="alert alert-info mb-0">No products found.</div></div>
  <?php endif; ?>

  <?php foreach ($data as $p): ?>
    <div class="col-6 col-md-3">
  <div class="card product-card h-100 position-relative">  
    <!-- Ảnh -->
    <div class="product-thumb">
  <img src="<?= e($p['image_url'] ?? $base.'public/images/placeholder.png') ?>" alt="<?= e($p['name']) ?>">
</div>

    <div class="card-body">
      <div class="small text-muted"><?= e($p['category_name'] ?? '') ?></div>
      <h3 class="h6 product-title mb-2"><?= e($p['name']) ?></h3>
      <div class="product-price">$<?= number_format((float)$p['price'], 2) ?></div>

      <a class="stretched-link"
         href="<?= $base ?>?page=product_detail&id=<?= (int)$p['id'] ?>"
         aria-label="Xem <?= e($p['name']) ?>"></a>
    </div>
  </div>
</div>
  <?php endforeach; ?>
</div>

<!-- PAGINATION -->
<?php if ($list['pages'] > 1): ?>
<nav class="mt-4">
  <ul class="pagination">
    <?php
      // giữ nguyên các tham số filter, chỉ thay 'p'
      for ($i = 1; $i <= $list['pages']; $i++):
        $params = $_GET; $params['page'] = 'products'; $params['p'] = $i;
        $url = '?' . http_build_query($params);
    ?>
      <li class="page-item <?= $i===$list['page']?'active':'' ?>">
        <a class="page-link" href="<?= $url ?>"><?= $i ?></a>
      </li>
    <?php endfor; ?>
  </ul>
</nav>
<?php endif; ?>

<script>
  // Tự submit khi đổi category/sort
  document.querySelectorAll('.filter-auto').forEach(el => {
    el.addEventListener('change', () => document.getElementById('filterForm').submit());
  });
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>
