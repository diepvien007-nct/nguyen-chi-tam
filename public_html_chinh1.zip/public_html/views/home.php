<?php
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Product.php';

$categories = Category::all();
$newProducts = Product::featured(8); // hiển thị sản phẩm mới

if (!function_exists('e')) { 
  function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); } 
}
?>
<?php include __DIR__ . '/partials/header.php'; ?>


<!-- SLIDER -->
<div id="homeCarousel" class="carousel slide mb-5" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?= $base ?>public/images/slider1.avif" class="d-block w-100" alt="Slide 1">
    </div>
    <div class="carousel-item">
      <img src="<?= $base ?>public/images/slider2.avif" class="d-block w-100" alt="Slide 2">
    </div>
    <div class="carousel-item">
      <img src="<?= $base ?>public/images/slider3.avif" class="d-block w-100" alt="Slide 3">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#homeCarousel" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#homeCarousel" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>



<!-- LOOP QUA TỪNG DANH MỤC -->
<?php foreach ($categories as $cat): ?>
  <h2 class="strip-title"><?= e($cat['name']) ?></h2>
  <section class="home-strip container-xxl px-0 mb-5">
    <div class="row g-4 justify-content-center">
      <?php 
        $products = Product::listing(['category_id' => $cat['id'], 'per_page' => 8]);
        foreach ($products['data'] as $p): 
      ?>
        <div class="col-6 col-md-3">
          <a class="tile" href="<?= $base ?>?page=product_detail&id=<?= (int)$p['id'] ?>">
            <div class="tile-thumb">
              <img src="<?= e($p['image_url'] ?? $base.'public/images/placeholder.png') ?>" alt="<?= e($p['name']) ?>">
            </div>
            <div class="tile-name"><?= e($p['name']) ?></div>
            <div class="tile-price">$<?= number_format((float)$p['price'], 2) ?></div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </section>
<?php endforeach; ?>

<!-- VIDEO STRIP -->
<section id="brand-video" class="container-xxl my-5">
  <h2 class="strip-title">Time in Motion</h2>
</p>

  <div class="row">
    <div class="col-lg-8 mx-auto">
      <div class="video-wrap shadow-sm rounded-4 overflow-hidden">
        <div class="ratio ratio-16x9">
          <!-- Chỗ  thay VIDEO_ID bằng id của video YouTube -->
          <iframe width="560" height="315" src="https://www.youtube.com/embed/jnRHja9zd1k?si=MoXK5RBNOrHMrIXp" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

        </div>
      </div>
    </div>
  </div>
</section>


<?php include __DIR__ . '/partials/footer.php'; ?>
