<?php
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Comment.php';

if (!isset($product) || !$product) { http_response_code(404); echo "Sản phẩm không tồn tại."; return; }
if (!function_exists('e')) { function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); } }

// ====== XỬ LÝ SUBMIT BÌNH LUẬN (POST) ======
$comment_notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['__action__'] ?? '') === 'create_comment') {
  if (session_status() !== PHP_SESSION_ACTIVE) session_start();

  $pid     = (int)($product['id'] ?? 0);
  $user_id = !empty($_SESSION['user']) ? (int)$_SESSION['user']['id'] : null;

  $rating  = (int)($_POST['rating'] ?? 0);
  $content = trim($_POST['content'] ?? '');

  $guest_name  = null;
  $guest_email = null;
  if ($user_id === null) { // khách
    $guest_name  = trim($_POST['guest_name'] ?? '');
    $guest_email = trim($_POST['guest_email'] ?? '');
  }

  // Validate cơ bản
  $errs = [];
  if ($rating < 1 || $rating > 5) $errs[] = 'Vui lòng chọn số sao (1–5).';
  if ($content === '' || mb_strlen($content) < 5) $errs[] = 'Nội dung bình luận tối thiểu 5 ký tự.';
  if ($user_id === null) {
    if ($guest_name === '') $errs[] = 'Vui lòng nhập Tên.';
    if ($guest_email === '' || !filter_var($guest_email, FILTER_VALIDATE_EMAIL)) $errs[] = 'Email không hợp lệ.';
  }

  if (!$errs) {
    try {
      // LƯU Ý: Hàm create() trong models/Comment.php phải đang INSERT với status='approved'
      Comment::create([
        'product_id' => $pid,
        'user_id'    => $user_id,
        'guest_name' => $guest_name,
        'guest_email'=> $guest_email,
        'rating'     => $rating,
        'content'    => $content,
      ]);
      // flash message: hiển thị ngay
      $_SESSION['comment_flash'] = 'Đã đăng bình luận!';
      header('Location: ?page=product_detail&id='.$pid);
      exit;
    } catch (Throwable $e) {
      $comment_notice = '<div class="alert alert-danger">Có lỗi khi gửi bình luận. Vui lòng thử lại.</div>';
    }
  } else {
    $comment_notice = '<div class="alert alert-danger"><ul class="mb-0"><li>'.implode('</li><li>', array_map('e',$errs)).'</li></ul></div>';
  }
}

// ====== LẤY DỮ LIỆU HIỂN THỊ ======
$name  = $product['name'] ?? 'Sản phẩm';
$price = isset($product['price']) ? number_format((float)$product['price'], 2) : '0.00';
$img   = $product['image_url'] ?? '';
$cat   = $product['category_name'] ?? '';
$desc  = $product['description'] ?? '';
$approvedComments = Comment::approvedByProduct((int)$product['id']); // comment mới cũng là approved nên lên ngay
$approvedCount    = count($approvedComments);
$avgRating        = Comment::avgRating((int)$product['id']);
?>
<?php include __DIR__ . '/partials/header.php'; ?>

<?php if (!empty($_SESSION['comment_flash'])): ?>
  <div class="alert alert-success"><?= e($_SESSION['comment_flash']); unset($_SESSION['comment_flash']); ?></div>
<?php endif; ?>
<?= $comment_notice ?>

<nav aria-label="breadcrumb" class="mb-3">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?= $base ?>?page=home">Trang chủ</a></li>
    <li class="breadcrumb-item"><a href="<?= $base ?>?page=products">Sản phẩm</a></li>
    <?php if($cat): ?>
      <li class="breadcrumb-item"><a href="<?= $base ?>?page=products&category_id=<?= (int)($product['category_id'] ?? 0) ?>"><?= e($cat) ?></a></li>
    <?php endif; ?>
    <li class="breadcrumb-item active" aria-current="page"><?= e($name) ?></li>
  </ol>
</nav>

<div class="row g-4">
  <div class="col-12 col-md-5">
    <div class="border rounded p-2 bg-white">
      <?php if ($img): ?>
        <img src="<?= e($img) ?>" alt="<?= e($name) ?>" class="img-fluid w-100">
      <?php else: ?>
        <div class="ratio ratio-1x1 d-flex align-items-center justify-content-center bg-light">
          <span class="text-muted">Chưa có ảnh</span>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-12 col-md-7">
    <h1 class="h3 mb-2"><?= e($name) ?></h1>

    <div class="d-flex align-items-center gap-2 mb-2">
      <?php if ($avgRating !== null): ?>
        <?php
          $full = floor($avgRating);
          $half = ($avgRating - $full) >= 0.5 ? 1 : 0;
          $empty = 5 - $full - $half;
        ?>
        <div>
          <?php for($i=0;$i<$full;$i++): ?><i class="bi bi-star-fill text-warning"></i><?php endfor; ?>
          <?php if ($half): ?><i class="bi bi-star-half text-warning"></i><?php endif; ?>
          <?php for($i=0;$i<$empty;$i++): ?><i class="bi bi-star text-warning"></i><?php endfor; ?>
        </div>
        <small class="text-muted">(<?= number_format($avgRating,1) ?>/5 • <?= $approvedCount ?> đánh giá)</small>
      <?php else: ?>
        <small class="text-muted">Chưa có đánh giá</small>
      <?php endif; ?>
    </div>

    <?php if($cat): ?><div class="text-muted mb-2">Danh mục: <?= e($cat) ?></div><?php endif; ?>
    <div class="h4 text-danger mb-3">$<?= $price ?></div>
    <?php if (!empty($product['sku'])): ?>
      <div class="mb-2"><small class="text-muted">Mã SP: <?= e($product['sku']) ?></small></div>
    <?php endif; ?>

    <div class="d-grid d-sm-flex gap-2 my-3">
      <a class="btn btn-primary" href="<?= $base ?>?page=cart&action=add&id=<?= (int)$product['id'] ?>">Thêm vào giỏ</a>
      <a class="btn btn-outline-secondary" href="<?= $base ?>?page=products">Tiếp tục mua sắm</a>
    </div>

    <hr>
    <div class="mb-3">
      <h2 class="h6">Mô tả</h2>
      <div class="text-body"><?= nl2br(e($desc ?: 'Sản phẩm chưa có mô tả.')) ?></div>
    </div>
  </div>
</div>

<!-- ====== BÌNH LUẬN ====== -->
<hr class="my-4">
<section id="comments">
  <div class="row g-4">
    <div class="col-12 col-lg-7">
      <h2 class="h6 d-flex align-items-center gap-2">
        <i class="bi bi-chat-left-text"></i> Bình luận (<?= (int)$approvedCount ?>)
      </h2>

      <?php if ($approvedCount === 0): ?>
        <div class="text-muted">Chưa có bình luận nào. Hãy là người đầu tiên!</div>
      <?php else: ?>
        <div class="list-group">
          <?php foreach ($approvedComments as $c): ?>
            <div class="list-group-item">
              <div class="d-flex justify-content-between">
                <strong><?= e($c['author'] ?? 'Khách') ?></strong>
                <small class="text-muted"><?= e($c['created_at']) ?></small>
              </div>
              <div class="mb-1">
                <?php for($i=1;$i<=5;$i++): ?>
                  <?php if ($i <= (int)$c['rating']): ?><i class="bi bi-star-fill text-warning"></i>
                  <?php else: ?><i class="bi bi-star text-warning"></i><?php endif; ?>
                <?php endfor; ?>
              </div>
              <div><?= nl2br(e($c['content'])) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="col-12 col-lg-5">
      <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body">
          <h3 class="h6 mb-3 d-flex align-items-center gap-2">
            <i class="bi bi-pencil-square"></i> Viết bình luận
          </h3>

          <form method="post">
            <input type="hidden" name="__action__" value="create_comment">

            <?php if (empty($_SESSION['user'])): ?>
              <div class="mb-3">
                <label class="form-label">Tên của bạn</label>
                <input class="form-control" name="guest_name" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Email</label>
                <input class="form-control" type="email" name="guest_email" required>
              </div>
            <?php else: ?>
              <div class="alert alert-info py-2">
                Đăng nhập với: <strong><?= e($_SESSION['user']['username']) ?></strong>
              </div>
            <?php endif; ?>

            <div class="mb-3">
              <label class="form-label d-block">Đánh giá</label>
              <div class="d-flex align-items-center gap-2 flex-wrap">
                <?php for($i=5;$i>=1;$i--): ?>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="rating" id="star<?= $i ?>" value="<?= $i ?>" required>
                    <label class="form-check-label" for="star<?= $i ?>">
                      <?php for($s=1;$s<=$i;$s++): ?><i class="bi bi-star-fill text-warning"></i><?php endfor; ?>
                      (<?= $i ?>)
                    </label>
                  </div>
                <?php endfor; ?>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Nội dung</label>
              <textarea class="form-control" name="content" rows="4" placeholder="Chia sẻ cảm nhận của bạn..." required></textarea>
            </div>

            <div class="d-grid">
              <button class="btn btn-primary" type="submit">
                <i class="bi bi-send me-1"></i> Gửi bình luận
              </button>
            </div>
            <div class="form-text mt-2">
              Bình luận của bạn sẽ hiển thị ngay.
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
// ====== SẢN PHẨM LIÊN QUAN ======
$related = [];
if (!empty($product['category_id'])) {
  $rel = Product::listing(['category_id' => $product['category_id'], 'per_page' => 4, 'page' => 1]);
  foreach (($rel['data'] ?? []) as $rp) {
    if ((int)$rp['id'] !== (int)$product['id']) $related[] = $rp;
  }
}
?>

<?php if (!empty($related)): ?>
<hr class="my-4">
<h2 class="h5 mb-3">Sản phẩm liên quan</h2>

<div class="row g-3">
  <?php foreach ($related as $p): ?>
    <div class="col-6 col-md-3">
      <div class="card h-100 shadow-sm position-relative">
        <!-- Ảnh vuông, không méo -->
        <div class="ratio ratio-1x1 p-2" style="background:#fff;border-bottom:1px solid #eef0f3;">
          <img
            src="<?= e($p['image_url'] ?? $base.'public/images/placeholder.png') ?>"
            alt="<?= e($p['name'] ?? '') ?>"
            style="object-fit:contain;width:100%;height:100%;">
        </div>

        <div class="card-body">
          <div class="small text-muted"><?= e($p['category_name'] ?? '') ?></div>
          <h3 class="h6 card-title mb-2"><?= e($p['name'] ?? '') ?></h3>
          <div class="fw-bold">$<?= number_format((float)($p['price'] ?? 0), 2) ?></div>
        </div>

        <a class="stretched-link"
           href="<?= $base ?>?page=product_detail&id=<?= (int)$p['id'] ?>"
           aria-label="Xem <?= e($p['name'] ?? '') ?>"></a>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>


<?php include __DIR__ . '/partials/footer.php'; ?>
