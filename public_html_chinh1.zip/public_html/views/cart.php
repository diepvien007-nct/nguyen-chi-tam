<?php
require_once __DIR__ . '/../models/Product.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Khởi tạo giỏ
if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
  $_SESSION['cart'] = [];
}

$action = $_GET['action'] ?? '';
$id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Xử lý hành động
if ($action === 'add' && $id > 0) {
  // ?page=cart&action=add&id=123&qty=2
  $qty = max(1, (int)($_GET['qty'] ?? 1));
  $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + $qty;
  header('Location: ?page=cart'); exit;
}

if ($action === 'remove' && $id > 0) {
  unset($_SESSION['cart'][$id]);
  header('Location: ?page=cart'); exit;
}

if ($action === 'clear') {
  $_SESSION['cart'] = [];
  header('Location: ?page=cart'); exit;
}

if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  // Form update số lượng hàng loạt
  foreach (($_POST['qty'] ?? []) as $pid => $q) {
    $pid = (int)$pid;
    $q   = max(0, (int)$q);
    if ($q === 0) unset($_SESSION['cart'][$pid]);
    else $_SESSION['cart'][$pid] = $q;
  }
  header('Location: ?page=cart'); exit;
}

// Lấy danh sách sản phẩm trong giỏ
$items = [];
$subtotal = 0.0;

if (!empty($_SESSION['cart'])) {
  foreach ($_SESSION['cart'] as $pid => $q) {
    $p = Product::find((int)$pid);
    if ($p) {
      $p['qty'] = (int)$q;
      $p['line_total'] = $p['qty'] * (float)$p['price'];
      $subtotal += $p['line_total'];
      $items[] = $p;
    }
  }
}

$shipping = ($subtotal > 0) ? 0.00 : 0.00; // bài tập: cho freeship
$grand    = $subtotal + $shipping;
?>
<?php include __DIR__ . '/partials/header.php'; ?>

<h1 class="mb-4"><i class="bi bi-cart4 me-2"></i>Giỏ hàng</h1>

<?php if (empty($items)): ?>
  <div class="alert alert-info">Giỏ hàng đang trống. <a href="?page=products">Tiếp tục mua sắm</a>.</div>
<?php else: ?>

<form method="post" action="?page=cart&action=update">
  <div class="card border-0 shadow-sm rounded-4">
    <div class="table-responsive">
      <table class="table align-middle mb-0">
        <thead class="table-light">
          <tr>
            <th style="width:64px"></th>
            <th>Sản phẩm</th>
            <th class="text-center" style="width:140px">Số lượng</th>
            <th class="text-end" style="width:140px">Đơn giá</th>
            <th class="text-end" style="width:160px">Thành tiền</th>
            <th class="text-end" style="width:80px">Xoá</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $it): ?>
          <tr>
            <td>
              <?php if (!empty($it['image_url'])): ?>
                <img src="<?= htmlspecialchars($it['image_url']) ?>" alt=""
                     style="width:56px;height:56px;object-fit:cover;border-radius:8px;">
              <?php endif; ?>
            </td>
            <td>
              <div class="fw-semibold"><?= htmlspecialchars($it['name']) ?></div>
              <small class="text-muted"><?= htmlspecialchars($it['category_name'] ?? '') ?></small>
              <?php if (!empty($it['sku'])): ?>
                <div><small class="text-muted">SKU: <?= htmlspecialchars($it['sku']) ?></small></div>
              <?php endif; ?>
            </td>
            <td class="text-center">
              <input type="number" name="qty[<?= (int)$it['id'] ?>]" min="0" class="form-control text-center"
                     value="<?= (int)$it['qty'] ?>" style="max-width:96px;margin:0 auto;">
            </td>
            <td class="text-end">$<?= number_format((float)$it['price'], 2) ?></td>
            <td class="text-end fw-semibold">$<?= number_format((float)$it['line_total'], 2) ?></td>
            <td class="text-end">
              <a class="btn btn-outline-danger btn-sm"
                 href="?page=cart&action=remove&id=<?= (int)$it['id'] ?>" title="Xoá">
                <i class="bi bi-trash"></i>
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="card-body">
      <div class="row g-3 justify-content-end">
        <div class="col-12 col-md-6 col-lg-4">
          <ul class="list-group list-group-flush">
            <li class="list-group-item d-flex justify-content-between">
              <span>Tạm tính</span>
              <strong>$<?= number_format($subtotal, 2) ?></strong>
            </li>
            <li class="list-group-item d-flex justify-content-between">
              <span>Phí vận chuyển</span>
              <strong>$<?= number_format($shipping, 2) ?></strong>
            </li>
            <!-- Coupon (chỉ là UI, chưa xử lý) -->
              <div class="mb-3">
                <label class="form-label fw-semibold mb-2">
                  Mã giảm giá
                </label>

                <form class="coupon-form" onsubmit="return false">
                  <div class="input-group coupon-input mb-3">
                    <input type="text" class="form-control" placeholder="Nhập mã giảm giá">
                    <button class="btn btn-outline-secondary">Áp dụng</button>
                  </div>
                </form>

            <li class="list-group-item d-flex justify-content-between">
              <span class="fw-bold">Tổng</span>
              <strong class="fs-5 text-danger">$<?= number_format($grand, 2) ?></strong>
            </li>
          </ul>

          <div class="d-grid gap-2 mt-3">
            <button class="btn btn-outline-primary" type="submit">
              <i class="bi bi-arrow-repeat me-1"></i> Cập nhật giỏ
            </button>
            <a class="btn btn-outline-secondary" href="?page=cart&action=clear"
               onclick="return confirm('Xoá toàn bộ giỏ hàng?')">
              <i class="bi bi-x-circle me-1"></i> Xoá giỏ
            </a>
            
            <a class="btn btn-primary" href="<?= $base ?>?page=checkout">
              <i class="bi bi-bag-check me-1"></i> Thanh toán
            </a>

            <a class="btn btn-light" href="?page=products">
              <i class="bi bi-shop me-1"></i> Tiếp tục mua sắm
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>

<?php endif; ?>

<?php include __DIR__ . '/partials/footer.php'; ?>
