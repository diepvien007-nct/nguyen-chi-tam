<?php
require_once __DIR__ . '/../models/User.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $emailOrUsername = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';

  $user = User::login($emailOrUsername, $password);

  if ($user) {
    $_SESSION['user'] = $user;
    header("Location: ?page=home");
    exit;
  } else {
    $notice = '<div class="alert alert-danger">Sai thông tin đăng nhập.</div>';
  }
}
?>

<?php include __DIR__ . '/partials/header.php'; ?>
<div class="row justify-content-center">
  <div class="col-md-6 col-lg-4">
    <div class="card shadow-sm rounded-4">
      <div class="card-body p-4">
        <h2 class="h4 text-center mb-3"><i class="bi bi-box-arrow-in-right"></i> Đăng nhập</h2>
        <?= $notice ?>
        <form method="post" novalidate>
          <div class="mb-3">
            <label class="form-label">Email hoặc Username</label>
            <input type="text" class="form-control" name="email" required>
          </div>
         <div class="mb-3">
  <label class="form-label">Mật khẩu</label>
  <div class="input-group">
    <input type="password" id="password" name="password" 
           class="form-control" minlength="8" required>
    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('password')">
      <i class="bi bi-eye"></i>
    </button>
  </div>
  <div class="form-text">Mật khẩu tối thiểu 8 ký tự.</div>
</div>

          <div class="d-grid">
            <button type="submit" class="btn btn-primary"><i class="bi bi-box-arrow-in-right"></i> Đăng nhập</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
