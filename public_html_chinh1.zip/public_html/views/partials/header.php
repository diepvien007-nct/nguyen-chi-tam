<?php
// --- POLYFILL cho str_starts_with nếu PHP < 8 ---
if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle): bool {
        if ($needle === '') return true;
        return strpos($haystack, $needle) === 0;
    }
}

// --- Tải file cấu hình an toàn ---
// Ghi nhớ: nếu app/config.php dùng define(...) và không return array,
// require/include sẽ trả về 1 (int). Vì vậy ta không dựa vào giá trị trả về.
$configReturn = @include __DIR__ . '/../../app/config.php';

// Xác định base url theo nhiều khả năng
$baseUrl = null;
if (is_array($configReturn)) {
    // Nếu config trả về mảng (như ['base_url'=>'...'])
    $baseUrl = $configReturn['base_url'] ?? $configReturn['BASE_URL'] ?? null;
}
if (!$baseUrl && defined('BASE_URL')) {
    $baseUrl = BASE_URL;
}
if (!$baseUrl) {
    // Fallback: đoán base từ host (không hoàn hảo nhưng an toàn)
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'http' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/\\');
    $baseUrl = $scheme . '://' . $host . $scriptDir . '/';
}
$base = rtrim($baseUrl, '/') . '/';

// --- Session ---
if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

// --- Đảm bảo $meta là mảng để tránh Notice ---
if (!isset($meta) || !is_array($meta)) {
    // Log để debug (có thể xoá dòng này sau khi ổn)
    error_log('header.php: $meta missing or not array. type=' . (isset($meta) ? gettype($meta) : 'undefined') . ' value=' . var_export($meta ?? null, true));
    $meta = [
        'title' => 'WatchShop',
        'description' => '',
        'keywords' => ''
    ];
}

// Lấy dữ liệu meta an toàn và escape đầu ra
$title = htmlspecialchars($meta['title'] ?? 'WatchShop', ENT_QUOTES, 'UTF-8');
$description = htmlspecialchars($meta['description'] ?? '', ENT_QUOTES, 'UTF-8');
$keywords = htmlspecialchars($meta['keywords'] ?? '', ENT_QUOTES, 'UTF-8');

// --- Xác định trang hiện tại ---
$current = $_GET['page'] ?? 'home';

// --- Đếm số lượng món trong giỏ an toàn ---
$cartCount = 0;
if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $val) {
        // Nếu cart có cấu trúc [id => ['qty'=>x]] hoặc [id => qty]
        if (is_array($val) && isset($val['qty'])) {
            $cartCount += (int)$val['qty'];
        } else {
            $cartCount += (int)$val;
        }
    }
}

// --- Xác định admin page (an toàn nếu $current là string) ---
$isAdminPage = is_string($current) && str_starts_with($current, 'admin_');

// --- Kiểm tra user trong session an toàn ---
$sessionUser = null;
if (!empty($_SESSION['user']) && is_array($_SESSION['user'])) {
    $sessionUser = $_SESSION['user'];
    // chuẩn hoá các trường thường dùng
    $sessionUser['username'] = htmlspecialchars($sessionUser['username'] ?? 'Người dùng', ENT_QUOTES, 'UTF-8');
    $sessionUser['role'] = $sessionUser['role'] ?? 'user';
} else {
    $sessionUser = null;
}
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <title><?= $title ?></title>
  <meta name="description" content="<?= $description ?>">
  <meta name="keywords" content="<?= $keywords ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

  <link href="<?= $base ?>public/css/style.css?v=tiles-1" rel="stylesheet">
</head>
<body class="bg-body-tertiary">

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="<?= $base ?>?page=home">
      <i class="bi bi-watch"></i> <span>WatchShop</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbars"
            aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbars">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link <?= $current==='home'?'active':'' ?>" href="<?= $base ?>?page=home">
            <i class="bi bi-house-door"></i> Trang chủ
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current==='products'?'active':'' ?>" href="<?= $base ?>?page=products">
            <i class="bi bi-grid"></i> Sản phẩm
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current==='promotions' ? 'active' : '' ?>" href="<?= $base ?>?page=promotions">
            <i class="bi bi-gift me-1"></i> Khuyến mãi
          </a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link <?= $current==='news' ? 'active' : '' ?>" href="<?= $base ?>?page=news">
            <i class="bi bi-newspaper me-1"></i> Tin tức
          </a>
        </li>
        <?php if (!empty($sessionUser) && ($sessionUser['role'] === 'admin')): ?>
          <li class="nav-item">
            <a class="nav-link <?= $isAdminPage?'active':'' ?>" href="<?= $base ?>?page=admin_dashboard">
              <i class="bi bi-speedometer2"></i> Admin
            </a>
          </li>
        <?php endif; ?>
      </ul>

      <form class="d-flex mx-auto nav-search" method="get">
        <input type="hidden" name="page" value="products">
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-search"></i></span>
          <input class="form-control" type="search" name="q"
                 placeholder="Tìm kiếm đồng hồ..."
                 value="<?= htmlspecialchars($_GET['q'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
          <button class="btn btn-primary" type="submit">Tìm</button>
        </div>
      </form>

      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item me-2">
          <a class="btn btn-outline-secondary position-relative" href="<?= $base ?>?page=cart">
            <i class="bi bi-cart"></i> Giỏ hàng
            <?php if ($cartCount > 0): ?>
              <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                <?= $cartCount ?>
              </span>
            <?php endif; ?>
          </a>
        </li>

        <?php if (!empty($sessionUser)): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle d-flex align-items-center gap-2" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle fs-5"></i>
              <span><?= $sessionUser['username'] ?></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="<?= $base ?>?page=profile"><i class="bi bi-person-fill me-2"></i>Thông tin</a></li>
              <li><a class="dropdown-item" href="<?= $base ?>?page=home"><i class="bi bi-house me-2"></i>Trang chủ</a></li>
              <?php if ($sessionUser['role'] === 'admin'): ?>
                <li><a class="dropdown-item" href="<?= $base ?>?page=admin_dashboard"><i class="bi bi-speedometer2 me-2"></i>Admin</a></li>
              <?php endif; ?>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="<?= $base ?>?page=logout"><i class="bi bi-box-arrow-right me-2"></i>Đăng xuất</a></li>
            </ul>
          </li>
        <?php else: ?>
          <li class="nav-item me-2">
            <a class="btn btn-outline-primary" href="<?= $base ?>?page=login">
              <i class="bi bi-box-arrow-in-right"></i> Đăng nhập
            </a>
          </li>
          <li class="nav-item">
            <a class="btn btn-primary" href="<?= $base ?>?page=register">
              <i class="bi bi-person-plus"></i> Đăng ký
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<main class="py-4">
  <div class="container">