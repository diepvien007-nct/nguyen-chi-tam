    </div>
</main>

<footer class="bg-light mt-5 pt-4 site-footer">
  <div class="container">

    <!-- Hàng icon chính sách -->
    <div class="row text-center mb-4">
      <div class="col-md-3">
        <i class="bi bi-truck fs-1 text-danger"></i>
        <h6 class="fw-bold mt-2">CHÍNH SÁCH GIAO HÀNG</h6>
        <small>Nhận hàng và thanh toán tại nhà</small>
      </div>
      <div class="col-md-3">
        <i class="bi bi-arrow-repeat fs-1 text-danger"></i>
        <h6 class="fw-bold mt-2">ĐỔI TRẢ DỄ DÀNG</h6>
        <small>1 đổi 1 trong 7 ngày</small>
      </div>
      <div class="col-md-3">
        <i class="bi bi-tag fs-1 text-danger"></i>
        <h6 class="fw-bold mt-2">GIÁ LUÔN RẺ NHẤT</h6>
        <small>Giá cả hợp lý, nhiều ưu đãi tốt</small>
      </div>
      <div class="col-md-3">
        <i class="bi bi-headset fs-1 text-danger"></i>
        <h6 class="fw-bold mt-2">HỖ TRỢ NHIỆT TÌNH</h6>
        <small>Tư vấn, giải đáp mọi thắc mắc</small>
      </div>
    </div>

    <hr>

    <!-- Hàng liên kết -->
    <div class="row text-muted">
      <div class="col-md-2">
        <h6 class="fw-bold">GIỚI THIỆU</h6>
        <ul class="list-unstyled">
          <li><a class="footer-link" href="<?= $base ?>?page=about">Về chúng tôi</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Tư vấn mua hàng</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Tuyển dụng</a></li>
        </ul>
        <div class="d-flex gap-2">
          <i class="bi bi-facebook"></i>
          <i class="bi bi-youtube"></i>
          <i class="bi bi-tiktok"></i>
          <i class="bi bi-linkedin"></i>
          <i class="bi bi-google"></i>
        </div>
      </div>
      <div class="col-md-3">
        <h6 class="fw-bold">CHÍNH SÁCH CHUNG</h6>
        <ul class="list-unstyled">
          <li><a href="#" class="text-muted text-decoration-none">Chính sách bảo mật</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Chính sách giao nhận, kiểm hàng</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Chính sách trả góp</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Chính sách thanh toán</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Chính sách giải quyết khiếu nại</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Chính sách bảo vệ thông tin cá nhân</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Chính sách bảo hành</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Chính sách đổi - trả hàng</a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <h6 class="fw-bold">THÔNG TIN KHUYẾN MÃI</h6>
        <ul class="list-unstyled">
           <li><a class="footer-link" href="<?= $base ?>?page=promotions">Tổng hợp khuyến mãi</a></li>
        </ul>
      </div>
      <div class="col-md-4">
        <h6 class="fw-bold">HỖ TRỢ KHÁCH HÀNG</h6>
        <ul class="list-unstyled">
          <li>CSKH: 0931 889 888</li>
          <li><a href="#" class="text-muted text-decoration-none">Tổng hợp hotline, phản ánh</a></li>
          <li><a href="#" class="text-muted text-decoration-none">Tra cứu bảo hành</a></li>
        </ul>
      </div>
    </div>

    <hr>

    <div class="text-center text-muted small py-3">
      © <?= date('Y') ?> CASIO COMPUTER CO., LTD.
    </div>
  </div>
</footer>

<script src="<?= $base ?>public/js/auth.js?v=1"></script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

// chatbot
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/68e8a084575356194fdf9bca/1j76b627l';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->


</body>
</html>
