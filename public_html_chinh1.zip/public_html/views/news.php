<?php
/**
 * views/news.php
 * Trang tin tức chính, nhúng header/footer và tối ưu SEO.
 * Cấu trúc danh sách bài viết và phân loại theo thương hiệu (KIẾN THỨC, Casio, Citizen, Orient, Seiko).
 */

// Lấy tham số 'brand' hiện tại, mặc định là 'knowledge' (KIẾN THỨC)
$current_brand = $_GET['brand'] ?? 'knowledge'; 

// Cập nhật tên thương hiệu
$brand_map = [
    'knowledge' => 'KIẾN THỨC ĐỒNG HỒ', 
    'casio' => 'CASIO',
    'citizen' => 'CITIZEN',
    'orient' => 'ORIENT',
    'seiko' => 'SEIKO',
];
$brand_name = $brand_map[$current_brand] ?? 'TIN TỨC CHUNG';

// ===========================================
// 1. THIẾT LẬP META SEO (Cập nhật theo thương hiệu)
// ===========================================
$meta['title'] = "Thư Viện Đồng Hồ $brand_name | Đánh Giá, Mẹo Chọn Mua Chuẩn SEO";
$meta['description'] = "Tổng hợp các bài viết chuyên sâu về $brand_name, đánh giá chi tiết sản phẩm và cẩm nang chọn mua đồng hồ chính hãng. Khám phá ngay!";
$meta['keywords'] = "tin tức đồng hồ, kiến thức đồng hồ, đánh giá đồng hồ, mua đồng hồ, đồng hồ chính hãng";

// ===========================================
// 2. NHÚNG HEADER
// ===========================================
// Giả định header.php nằm trong views/partials/header.php
require_once __DIR__ . '/partials/header.php';
?>

<style>
/* Bố cục danh sách bài viết */
.news-item-list {
    display: flex;
    flex-direction: column;
    gap: 25px; /* Tăng khoảng cách giữa các bài viết */
}
.news-item-article {
    display: flex;
    padding-bottom: 25px;
    border-bottom: 1px solid #eee;
    transition: background-color 0.3s;
}
.news-item-article:hover {
    background-color: #fcfcfc; /* Highlight nhẹ khi hover */
}
.news-item-article:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

/* ẢNH ĐẠI DIỆN BÀI VIẾT (ĐÃ CHỈNH SỬA) */
.article-image {
    flex-shrink: 0;
    position: relative;
    width: 240px; /* TĂNG ĐỘ RỘNG ẢNH */
    height: 140px; /* TĂNG CHIỀU CAO ẢNH */
    margin-right: 20px;
    overflow: hidden;
    border-radius: 6px; /* BO GÓC ẢNH */
}
.article-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
}
.news-item-article:hover .article-image img {
    transform: scale(1.05);
}

/* Icon Video */
.video-icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    font-size: 2.8rem; /* Tăng kích thước icon */
    background-color: rgba(0, 0, 0, 0.5);
    border-radius: 50%;
    padding: 5px 8px 5px 12px;
    transition: opacity 0.3s;
    opacity: 0.8;
}
.news-item-article:hover .video-icon {
    opacity: 1;
}

.article-body h2 {
    font-size: 1.35rem; /* Tăng nhẹ kích thước tiêu đề */
    color: #333;
    margin-top: 0;
    margin-bottom: 8px;
    font-weight: 600;
}
.article-body a {
    text-decoration: none;
    color: inherit;
}
.article-body a:hover h2 {
    color: #0d6efd; /* Màu xanh Primary của Bootstrap/Codewithme */
}
.article-meta {
    font-size: 0.85rem;
    color: #999;
    margin-bottom: 8px;
}
.article-snippet {
    font-size: 0.95rem; /* Tăng nhẹ kích thước đoạn trích */
    color: #555;
    line-height: 1.5;
}

/* Menu phân loại thương hiệu (Tabs) */
.brand-nav .nav-link {
    color: #666;
    border: none;
    border-bottom: 3px solid transparent;
    font-weight: 600;
    padding: 8px 0; 
    margin-right: 20px;
}
/* MÀU XANH ACTIVE (Primary Color) cho menu */
.brand-nav .nav-link.active {
    color: #0d6efd; /* Màu xanh Primary */
    border-bottom-color: #0d6efd; /* Dải xanh dưới */
    background-color: transparent;
}

/* Breadcrumb */
.custom-breadcrumb {
    font-size: 0.9rem;
    color: #6c757d;
}
.custom-breadcrumb a {
    color: #0d6efd;
    text-decoration: none;
}
.custom-breadcrumb span {
    color: #333;
    font-weight: 500;
}

/* Sidebar CTA (Đã dùng màu xanh primary) */
.cta-banner-custom {
    background-color: #e6f0ff; /* Nền xanh nhạt */
    color: #0d6efd;
    padding: 20px;
    border-radius: 8px;
    text-align: center;
    border: 1px solid #c2d9ff;
}

/* TIN KHUYẾN MÃI SIDEBAR MỚI (ĐÃ CHỈNH SỬA CHO ĐẸP HƠN) */
.promotion-news-box {
    background-color: #f1f7fe; /* Nền xanh nhạt, hài hòa với theme */
    border: 1px solid #c2d9ff; /* Border màu xanh nhạt */
    padding: 15px;
    border-radius: 12px; /* Góc bo tròn hơn */
    margin-top: 25px; 
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); /* Bóng đổ nhẹ, hiện đại */
    transition: transform 0.3s ease, box-shadow 0.3s ease; 
    cursor: pointer;
}
.promotion-news-box:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
}
.promotion-news-box h4 {
    color: #0d6efd; 
    font-size: 1.15rem; 
    font-weight: 700;
    margin-bottom: 12px;
    padding-bottom: 5px;
    border-bottom: 1px dashed #c2d9ff;
}
.promotion-news-box img {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 8px; 
    margin-bottom: 12px;
}
.promotion-news-box .text-dark:hover {
    color: #0d6efd !important;
}
.promotion-news-box .fw-bold.fs-6 {
    line-height: 1.4;
    margin-bottom: 8px;
}
.promotion-news-box .small a {
    text-decoration: none;
}
</style>


<div class="container py-4">
    <div class="row">
        <div class="col-lg-12">
            
            <div class="custom-breadcrumb mb-3">
                <a href="<?= $base ?>?page=home">Đồng Hồ</a> / 
                <a href="<?= $base ?>?page=news">Tin Tức</a> / 
                <span>Thư Viện <?= $brand_name ?></span>
            </div>

            <header class="mb-4 border-bottom pb-2">
                <h1 class="fw-bold fs-2"><?= $brand_name ?></h1>
            </header>
            
            <nav class="mb-4">
                <ul class="nav brand-nav">
                    <?php foreach ($brand_map as $key => $name): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= $current_brand === $key ? 'active' : '' ?>" 
                            href="<?= $base ?>?page=news&brand=<?= $key ?>">
                            <?= $name ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="news-item-list">

                <?php if ($current_brand === 'knowledge'): ?>
                    <p class="text-muted small">Các bài viết cơ bản và chuyên sâu về thuật ngữ, lịch sử, mẹo và cách bảo quản đồng hồ.</p>
                    
                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=knowledge&slug=dong-ho-co-khong-chay-hieu-qua" class="article-image">
                            <img src="<?= $base ?>public/images/b1.jpg" 
                                alt="Đồng hồ cơ không chạy: Nguyên nhân và cách xử lý" 
                                class="img-fluid">
                             </a>
                        <div class="article-body">
                                <h2>Đồng hồ cơ không chạy: Nguyên nhân và cách xử lý hiệu quả nhất</h2>
                            </a>
                            <p class="article-meta">An Nhã | 13/10/2025</p>
                            <p class="article-snippet">Đồng hồ cơ ngừng chạy có thể do thiếu cót, va đập mạnh hoặc khô dầu. Hướng dẫn chi tiết cách kiểm tra và xử lý sự cố thường gặp để bảo vệ cỗ máy của bạn.</p>
                        </div>
                    </article>

                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=knowledge&slug=sua-chua-dong-ho-ha-noi-uy-tin" class="article-image">
                            <img src="<?= $base ?>public/images/b2.jpg" 
                                alt="Địa chỉ sửa chữa đồng hồ uy tín" 
                                class="img-fluid">
                        </a>
                        <div class="article-body">
                                <h2>Sửa chữa đồng hồ tại Hà Nội/TP.HCM: Hướng dẫn tìm địa chỉ uy tín và an toàn</h2>
                            </a>
                            <p class="article-meta">Minh Khang | 06/10/2025</p>
                            <p class="article-snippet">Đồng hồ là phụ kiện có giá trị, việc sửa chữa cần sự cẩn trọng. Bài viết tổng hợp các tiêu chí và địa chỉ trung tâm bảo hành, sửa chữa đồng hồ uy tín.</p>
                        </div>
                    </article>

                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=knowledge&slug=dress-watch-la-gi-cach-chon" class="article-image">
                            <img src="<?= $base ?>public/images/knowledge-dress-watch-thumb.jpg" 
                                alt="Dress Watch là gì?" 
                                class="img-fluid">
                            <i class="bi bi-play-circle-fill video-icon" title="Xem Video"></i> </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=knowledge&slug=dress-watch-la-gi-cach-chon">
                                <h2>Dress Watch là gì? Những chiếc đồng hồ dành riêng cho tiệc tùng và công sở</h2>
                            </a>
                            <p class="article-meta">Văn Long | 08/10/2025</p>
                            <p class="article-snippet">Dress Watch là phong cách đồng hồ thanh lịch, đơn giản và tinh tế, phù hợp với trang phục suit. Hướng dẫn chi tiết cách chọn kích thước và màu sắc dây đeo.</p>
                        </div>
                    </article>

                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=knowledge&slug=thuật-ngữ-đồng-hồ-cần-biết" class="article-image">
                            <img src="<?= $base ?>public/images/knowledge-thuật-ngữ-thumb.jpg" 
                                alt="Thuật ngữ đồng hồ cơ bản và nâng cao" 
                                class="img-fluid">
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=knowledge&slug=thuật-ngữ-đồng-hồ-cần-biết">
                                <h2>Thuật ngữ Đồng hồ là gì? Những từ vựng cần biết khi chơi đồng hồ</h2>
                            </a>
                            <p class="article-meta">Văn Long | 01/09/2025</p>
                            <p class="article-snippet">Tìm hiểu các thuật ngữ chuyên ngành như Water Resistance, Automatic, Tourbillon, Chronograph... giúp bạn tự tin hơn khi trao đổi về đồng hồ.</p>
                        </div>
                    </article>

                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=knowledge&slug=lich-su-dong-ho-thuy-si" class="article-image">
                            <img src="<?= $base ?>public/images/knowledge-swiss-history-thumb.jpg" 
                                alt="Lịch sử ngành đồng hồ Thụy Sĩ" 
                                class="img-fluid">
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=knowledge&slug=lich-su-dong-ho-thuy-si">
                                <h2>Nguồn gốc và lịch sử phát triển của ngành công nghiệp đồng hồ Thụy Sĩ</h2>
                            </a>
                            <p class="article-meta">Thùy Linh | 15/08/2025</p>
                            <p class="article-snippet">Khám phá hành trình hơn 500 năm phát triển của ngành chế tác đồng hồ Thụy Sĩ, từ những xưởng thủ công đầu tiên đến thương hiệu xa xỉ toàn cầu.</p>
                        </div>
                    </article>

                <?php elseif ($current_brand === 'casio'): ?>
                    <p class="text-muted small">Các bài viết chuyên sâu về thương hiệu Casio.</p>
                    
                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=casio&slug=dong-ho-casio-anh-khue" class="article-image">
                            <img src="<?= $base ?>public/images/casio-anh-khue-thumb.jpg" 
                                alt="Nhà phân phối chính thức Casio Anh Khuê tại Việt Nam" 
                                class="img-fluid">
                            <i class="bi bi-play-circle-fill video-icon" title="Xem Video"></i>
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=casio&slug=dong-ho-casio-anh-khue">
                                <h2>Đồng hồ Casio Anh Khuê là gì, có nên mua không?</h2>
                            </a>
                            <p class="article-meta">An Nhã | 25/06/2025</p>
                            <p class="article-snippet">Đồng hồ Casio Anh Khuê – Nhà phân phối Casio chính thức và duy nhất tại thị trường Việt Nam. Tất cả đồng hồ mua không có tem Anh Khuê phần lớn đều là hàng giả.</p>
                        </div>
                    </article>
                    
                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=casio&slug=trung-tam-bao-hanh-casio-viet-nam" class="article-image">
                            <img src="<?= $base ?>public/images/casio-trung-tam-bh-thumb.jpg" 
                                alt="Địa chỉ trung tâm bảo hành Casio chính hãng tại Việt Nam" 
                                class="img-fluid">
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=casio&slug=trung-tam-bao-hanh-casio-viet-nam">
                                <h2>Địa chỉ trung tâm bảo hành Casio chính hãng tại Việt Nam</h2>
                            </a>
                            <p class="article-meta">An Nhã | 25/06/2025</p>
                            <p class="article-snippet">Cung cấp các địa chỉ trung tâm bảo hành Casio chính thức tại các thành phố lớn để khách hàng yên tâm khi sử dụng sản phẩm.</p>
                        </div>
                    </article>

                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=casio&slug=g-shock-la-gi-va-nhung-mau-moi" class="article-image">
                            <img src="<?= $base ?>public/images/casio-g-shock-thumb.jpg" 
                                alt="G-Shock là gì và các mẫu mới nhất" 
                                class="img-fluid">
                            <i class="bi bi-play-circle-fill video-icon" title="Xem Video"></i>
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=casio&slug=g-shock-la-gi-va-nhung-mau-moi">
                                <h2>G-Shock là gì? Top 5 mẫu G-Shock mới nhất được giới trẻ săn lùng</h2>
                            </a>
                            <p class="article-meta">Thùy Linh | 10/05/2025</p>
                            <p class="article-snippet">Khám phá dòng đồng hồ bền bỉ nhất thế giới của Casio, các công nghệ chống sốc và chống nước hàng đầu được áp dụng.</p>
                        </div>
                    </article>

                <?php elseif ($current_brand === 'citizen'): ?>
                    <p class="text-muted small">Các bài viết chuyên sâu về thương hiệu Citizen.</p>
                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=citizen&slug=citizen-eco-drive-la-gi" class="article-image">
                            <img src="<?= $base ?>public/images/citizen-eco-drive-thumb.jpg" 
                                alt="Công nghệ Citizen Eco-Drive" 
                                class="img-fluid">
                            <i class="bi bi-play-circle-fill video-icon" title="Xem Video"></i>
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=citizen&slug=citizen-eco-drive-la-gi">
                                <h2>Công nghệ Citizen Eco-Drive là gì? Cách thức hoạt động và lợi ích</h2>
                            </a>
                            <p class="article-meta">Minh Khang | 01/08/2025</p>
                            <p class="article-snippet">Citizen Eco-Drive là công nghệ pin năng lượng mặt trời hàng đầu. Khám phá nguyên lý hoạt động đột phá này và tại sao bạn nên sở hữu một chiếc.</p>
                        </div>
                    </article>

                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=citizen&slug=lich-su-thuong-hieu-citizen" class="article-image">
                            <img src="<?= $base ?>public/images/citizen-history-thumb.jpg" 
                                alt="Lịch sử thương hiệu Citizen" 
                                class="img-fluid">
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=citizen&slug=lich-su-thuong-hieu-citizen">
                                <h2>Hành trình phát triển của Citizen: Từ đồng hồ bỏ túi đến thương hiệu toàn cầu</h2>
                            </a>
                            <p class="article-meta">An Nhã | 15/07/2025</p>
                            <p class="article-snippet">Tìm hiểu về lịch sử thành lập, những phát minh nổi bật (như Eco-Drive) và vai trò của Citizen trong ngành công nghiệp đồng hồ Nhật Bản.</p>
                        </div>
                    </article>

                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=citizen&slug=danh-gia-dong-ho-promaster" class="article-image">
                            <img src="<?= $base ?>public/images/citizen-promaster-thumb.jpg" 
                                alt="Đánh giá đồng hồ Citizen Promaster" 
                                class="img-fluid">
                            <i class="bi bi-play-circle-fill video-icon" title="Xem Video"></i>
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=citizen&slug=danh-gia-dong-ho-promaster">
                                <h2>Đánh giá chi tiết Citizen Promaster: Dòng đồng hồ chuyên nghiệp tốt nhất</h2>
                            </a>
                            <p class="article-meta">Văn Long | 05/06/2025</p>
                            <p class="article-snippet">Promaster là dòng đồng hồ thể thao chuyên dụng (lặn, phi công, thám hiểm) của Citizen. Chúng tôi đánh giá khả năng chịu đựng và công nghệ của dòng này.</p>
                        </div>
                    </article>

                <?php elseif ($current_brand === 'orient'): ?>
                    <p class="text-muted small">Các bài viết chuyên sâu về thương hiệu Orient.</p>
                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=orient&slug=danh-gia-orient-star" class="article-image">
                            <img src="<?= $base ?>public/images/orient-star-review-thumb.jpg" 
                                alt="Đánh giá đồng hồ Orient Star" 
                                class="img-fluid">
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=orient&slug=danh-gia-orient-star">
                                <h2>Đánh giá chi tiết Orient Star: Đối thủ nặng ký trong phân khúc tầm trung</h2>
                            </a>
                            <p class="article-meta">Văn Long | 10/06/2025</p>
                            <p class="article-snippet">Orient Star là dòng sản phẩm cao cấp của Orient. Chúng tôi phân tích thiết kế, chất lượng bộ máy và so sánh với các đối thủ trong tầm giá.</p>
                        </div>
                    </article>
                    
                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=orient&slug=sun-and-moon-co-gi-dac-biet" class="article-image">
                            <img src="<?= $base ?>public/images/orient-sun-moon-thumb.jpg" 
                                alt="Orient Sun and Moon có gì đặc biệt" 
                                class="img-fluid">
                            <i class="bi bi-play-circle-fill video-icon" title="Xem Video"></i>
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=orient&slug=sun-and-moon-co-gi-dac-biet">
                                <h2>Bộ sưu tập Orient Sun & Moon: Tính năng độc đáo và vẻ đẹp khó cưỡng</h2>
                            </a>
                            <p class="article-meta">Minh Khang | 01/05/2025</p>
                            <p class="article-snippet">Khám phá cơ chế hiển thị ngày/đêm độc quyền của Orient (Sun and Moon) và những mẫu bán chạy nhất của dòng sản phẩm này.</p>
                        </div>
                    </article>
                    
                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=orient&slug=orient-bambino-co-nen-mua" class="article-image">
                            <img src="<?= $base ?>public/images/orient-bambino-thumb.jpg" 
                                alt="Đánh giá Orient Bambino" 
                                class="img-fluid">
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=orient&slug=orient-bambino-co-nen-mua">
                                <h2>Vì sao Orient Bambino là "Dress Watch quốc dân" trong tầm giá 5 triệu?</h2>
                            </a>
                            <p class="article-meta">Thùy Linh | 20/04/2025</p>
                            <p class="article-snippet">Bambino nổi tiếng với mặt kính vòm (domed crystal) và thiết kế cổ điển. Bài viết đánh giá chi tiết chất lượng và bộ máy của Bambino.</p>
                        </div>
                    </article>
                    
                <?php elseif ($current_brand === 'seiko'): ?>
                    <p class="text-muted small">Các bài viết chuyên sâu về thương hiệu Seiko.</p>
                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=seiko&slug=seiko-presage-co-tot-khong" class="article-image">
                            <img src="<?= $base ?>public/images/seiko-presage-cocktail-thumb.jpg" 
                                alt="Đồng hồ Seiko Presage Cocktail" 
                                class="img-fluid">
                            <i class="bi bi-play-circle-fill video-icon" title="Xem Video"></i>
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=seiko&slug=seiko-presage-co-tot-khong">
                                <h2>Seiko Presage có tốt không? Đánh giá dòng đồng hồ dress watch huyền thoại</h2>
                            </a>
                            <p class="article-meta">Thùy Linh | 18/07/2025</p>
                            <p class="article-snippet">Dòng Presage của Seiko nổi tiếng với các mẫu đồng hồ Dress Watch sang trọng. Chúng tôi sẽ mổ xẻ chất lượng bộ máy 4R và thiết kế mặt số phức tạp.</p>
                        </div>
                    </article>
                    
                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=seiko&slug=seiko-5-sports-danh-gia" class="article-image">
                            <img src="<?= $base ?>public/images/seiko-5-sports-thumb.jpg" 
                                alt="Đánh giá Seiko 5 Sports" 
                                class="img-fluid">
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=seiko&slug=seiko-5-sports-danh-gia">
                                <h2>Seiko 5 Sports: Dòng đồng hồ cơ huyền thoại trở lại có gì khác biệt?</h2>
                            </a>
                            <p class="article-meta">An Nhã | 05/06/2025</p>
                            <p class="article-snippet">Phân tích sự khác biệt giữa Seiko 5 Sports mới và cũ, và lý do dòng này vẫn được coi là lựa chọn hàng đầu trong phân khúc đồng hồ cơ giá rẻ.</p>
                        </div>
                    </article>

                    <article class="news-item-article">
                        <a href="<?= $base ?>?page=news_detail&brand=seiko&slug=seiko-prospex-danh-gia" class="article-image">
                            <img src="<?= $base ?>public/images/seiko-prospex-thumb.jpg" 
                                alt="Đánh giá Seiko Prospex" 
                                class="img-fluid">
                            <i class="bi bi-play-circle-fill video-icon" title="Xem Video"></i>
                        </a>
                        <div class="article-body">
                            <a href="<?= $base ?>?page=news_detail&brand=seiko&slug=seiko-prospex-danh-gia">
                                <h2>Seiko Prospex: Đánh giá chi tiết bộ sưu tập đồng hồ lặn chuyên nghiệp</h2>
                            </a>
                            <p class="article-meta">Văn Long | 12/04/2025</p>
                            <p class="article-snippet">Prospex là viết tắt của "Professional Specifications". Bài viết đánh giá các công nghệ chịu áp suất, chống nước và thiết kế đặc trưng của dòng này.</p>
                        </div>
                    </article>
                <?php else: ?>
                    <div class="alert alert-info" role="alert">
                        Không tìm thấy bài viết cho danh mục này. Vui lòng chọn một danh mục khác.
                    </div>
                <?php endif; ?>
                
            </div>
            
        </div>

        <div class="col-lg-4">
            
            <div class="sidebar-box mb-4 shadow-sm">
                <h3 class="mb-3 text-dark fw-bold border-bottom pb-2">CHỦ ĐỀ NỔI BẬT</h3>
                <ul class="list-group list-group-flush category-menu">
                    <li class="list-group-item"><i class="bi bi-arrow-right-short me-2"></i><a href="<?= $base ?>?page=news&brand=knowledge">Từ Điển Đồng Hồ</a></li>
                    <li class="list-group-item"><i class="bi bi-arrow-right-short me-2"></i><a href="<?= $base ?>?page=news&cat=meo-chon-mua">Mẹo Chọn Mua Đồng Hồ</a></li>
                    <li class="list-group-item"><i class="bi bi-arrow-right-short me-2"></i><a href="<?= $base ?>?page=news&cat=ve-thuong-hieu">Về Thương Hiệu</a></li>
                </ul>
            </div>
            
            <div class="cta-banner-custom shadow-sm mb-4">
                <i class="bi bi-watch fs-3 mb-2 text-primary"></i>
                <h4 class="fw-bold text-primary">Tìm Mẫu Đồng Hồ Chính Hãng</h4>
                <p class="text-secondary">Khám phá bộ sưu tập đồng hồ đang được giảm giá tại WatchShop!</p>
                <a href="<?= $base ?>?page=products" class="btn btn-primary btn-lg mt-2">Xem Sản Phẩm →</a>
            </div>

            <div class="promotion-news-box shadow-sm">
                <h4><i class="bi bi-tags-fill me-2"></i>TIN KHUYẾN MÃI MỚI NHẤT</h4>
                <a href="<?= $base ?>?page=promotions">
                    <img src="<?= $base ?>public/images/promotion-banner-thumb.jpg" 
                        alt="Khuyến mãi cuối năm WatchShop" 
                        class="img-fluid">
                </a>
                <a href="<?= $base ?>?page=promotions" class="text-decoration-none text-dark">
                    <h5 class="fw-bold fs-6">Sự Kiện Giảm Giá Cuối Năm: Ưu Đãi Lên Đến 50% Toàn Bộ Sản Phẩm!</h5>
                </a>
                <p class="text-muted small mb-1">WatchShop | 20/10/2025</p>
                <p class="small">Đừng bỏ lỡ cơ hội sở hữu đồng hồ chính hãng với mức giảm giá chưa từng có. Chương trình áp dụng cho tất cả các thương hiệu... <a href="<?= $base ?>?page=promotions" class="text-primary fw-bold">Đọc thêm</a></p>
            </div>

        </div>
    </div>
</div>

<?php 
// ===========================================
// 4. NHÚNG FOOTER
// ===========================================
// Giả định footer.php nằm trong views/partials/footer.php
require_once __DIR__ . '/partials/footer.php';
?>