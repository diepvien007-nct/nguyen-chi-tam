<?php
require_once __DIR__ . '/../models/User.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$notice = '';
$username = trim($_POST['username'] ?? '');
$email    = trim($_POST['email'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $password = $_POST['password'] ?? '';
  $confirm  = $_POST['confirm'] ?? '';

  $errs = [];
  if ($username === '') $errs[] = 'Vui lòng nhập username.';
  if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errs[] = 'Email không hợp lệ.';
  if ($password !== $confirm) $errs[] = 'Mật khẩu nhập lại không khớp.';

  // Ràng buộc mật khẩu
  if (strlen($password) < 8) $errs[] = 'Mật khẩu tối thiểu 8 ký tự.';
  if (!preg_match('/[A-Z]/', $password)) $errs[] = 'Mật khẩu phải có ít nhất 1 chữ hoa.';
  if (!preg_match('/[a-z]/', $password)) $errs[] = 'Mật khẩu phải có ít nhất 1 chữ thường.';
  if (!preg_match('/\d/', $password))    $errs[] = 'Mật khẩu phải có ít nhất 1 số.';
  if (!preg_match('/[^A-Za-z0-9]/', $password)) $errs[] = 'Mật khẩu phải có ít nhất 1 ký tự đặc biệt.';

  if (!$errs) {
    try {
      User::create($username, $email, $password);
      $_SESSION['register_success'] = "Đăng ký thành công, hãy đăng nhập.";
      header("Location: ?page=login");
      exit;
    } catch (Throwable $e) {
      $errs[] = "Lỗi khi đăng ký: " . $e->getMessage();
    }
  }
  if ($errs) {
    $notice = '<div class="alert alert-danger"><ul class="mb-0"><li>'.implode('</li><li>', $errs).'</li></ul></div>';
  }
}
?>

<?php include __DIR__ . '/partials/header.php'; ?>
<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5">
    <div class="card shadow-sm rounded-4">
      <div class="card-body p-4">
        <h2 class="h4 text-center mb-3"><i class="bi bi-person-plus"></i> Tạo tài khoản</h2>
        <?= $notice ?>
        <form method="post" novalidate>
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" class="form-control" name="username" value="<?= htmlspecialchars($username) ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($email) ?>" required>
          </div>
          <div class="mb-3">
  <label class="form-label">Mật khẩu</label>
  <div class="input-group">
    <input type="password"
           id="password"
           name="password"
           class="form-control"
           required
           oninput="pwCheck()">   
    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('password')">
      <i class="bi bi-eye"></i>
    </button>
  </div>

  <!-- Checklist  -->
  <div class="form-text mt-2">
    <ul class="mb-0 list-unstyled">
      <li id="rule-length"  class="text-danger">❌ Tối thiểu 8 ký tự</li>
      <li id="rule-lower"   class="text-danger">❌ Có ít nhất 1 chữ thường</li>
      <li id="rule-upper"   class="text-danger">❌ Có ít nhất 1 chữ hoa</li>
      <li id="rule-number"  class="text-danger">❌ Có ít nhất 1 số</li>
      <li id="rule-special" class="text-danger">❌ Có ít nhất 1 ký tự đặc biệt</li>
    </ul>
  </div>
</div>


          <div class="mb-3">
            <label class="form-label">Xác nhận mật khẩu</label>
            <input type="password" class="form-control" name="confirm" required>
          </div>
          <div class="d-grid">
            <button type="submit" class="btn btn-primary"><i class="bi bi-person-plus"></i> Đăng ký</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
