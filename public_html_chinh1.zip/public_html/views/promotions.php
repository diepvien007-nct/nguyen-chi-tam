<?php include __DIR__ . '/partials/header.php'; ?>

<section class="hero-slim">
  <div class="container-xxl">
    <h1 class="hero-title">Tổng hợp khuyến mãi</h1>
    <p class="hero-sub">Ưu đãi tốt – cập nhật thường xuyên</p>
  </div>
</section>

<section class="container-xxl py-4 py-md-5">
  <div class="row g-4">
    <!-- Promo 1 -->
    <div class="col-12 col-md-6 col-lg-4">
      <div class="promo-card">
        <div class="promo-thumb">
          <img src="<?= $base ?>public/images/summersale1.avif" alt="Summer Sale">
          <span class="promo-badge">-20%</span>
        </div>
        <div class="promo-body">
          <div class="promo-title">Summer Sale – Casio & Seiko</div>
          <div class="promo-meta">Thời gian: 10/08 – 31/08</div>
          <p class="promo-desc">Giảm trực tiếp trên giá bán, số lượng có hạn.</p>
         <a class="btn btn-outline-primary w-100" href="<?= $base ?>?page=products">
            Mua ngay
          </a>
        </div>
      </div>
    </div>

    <!-- Promo 2 -->
    <div class="col-12 col-md-6 col-lg-4">
      <div class="promo-card">
        <div class="promo-thumb">
          <img src="<?= $base ?>public/images/thanhvienmoi1.avif" alt="New Member">
          <span class="promo-badge">-10%</span>
        </div>
        <div class="promo-body">
          <div class="promo-title">Ưu đãi thành viên mới</div>
          <div class="promo-meta">Thời gian: 01/09 – 15/09</div>
          <p class="promo-desc">Mua ngay trong thời gian vàng để được trợ giá
          <a class="btn btn-outline-primary w-100" href="<?= $base ?>?page=products">
            Khám phá sản phẩm
          </a>
        </div>
      </div>
    </div>

    <!-- Promo 3 -->
    <div class="col-12 col-md-6 col-lg-4">
      <div class="promo-card">
        <div class="promo-thumb">
          <img src="<?= $base ?>public/images/citizen.avif" alt="Orient Week">
          <span class="promo-badge">Deal</span>
        </div>
        <div class="promo-body">
          <div class="promo-title">Citizen Week – Giá tốt mỗi ngày</div>
          <div class="promo-meta">Thời gian: Tuần này</div>
          <p class="promo-desc">Freeship + quà tặng dây da cho một số model.</p>
          <a class="btn btn-outline-primary w-100" href="<?= $base ?>?page=products&category_id=3">
            Xem đồng hồ Citizen
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/partials/footer.php'; ?>
