<?php include __DIR__ . '/partials/header.php'; ?>

<section class="hero-slim">
  <div class="container-xxl">
    <h1 class="hero-title">Về WatchShop</h1>
    <p class="hero-sub">Chọn chiếc đồng hồ phù hợp – theo phong cách của bạn</p>
  </div>
</section>

<section class="container-xxl py-4 py-md-5">
  <div class="row g-4 align-items-center">
    <div class="col-md-6">
      <img class="img-fluid rounded-4 shadow-sm" src="<?= $base ?>public/images/gioithieuvechungtoi.avif"
           alt="WatchShop">
    </div>
    <div class="col-md-6">
      <h2 class="h4 mb-3">Câu chuyện của chúng tôi</h2>
      <p>
        WatchShop là cửa hàng đồng hồ trực tuyến được xây dựng với mục tiêu đem lại trải nghiệm mua sắm
        rõ ràng, minh bạch và nhanh chóng. Chúng tôi tuyển chọn kỹ những mẫu đồng hồ chính hãng từ
        Casio, Seiko, Orient, Citizen… với mức giá cạnh tranh.
      </p>
      <p>
        Không chỉ bán hàng, chúng tôi muốn đồng hành cùng bạn để chọn được chiếc đồng hồ khiến bạn
        tự tin mỗi ngày.
      </p>

      <div class="row g-3 mt-3">
        <div class="col-6">
          <div class="feature-tile">
            <i class="bi bi-shield-check"></i>
            <div>
              <div class="fw-semibold">Chính hãng 100%</div>
              <small class="text-muted">Nguồn hàng minh bạch</small>
            </div>
          </div>
        </div>
        <div class="col-6">
          <div class="feature-tile">
            <i class="bi bi-truck"></i>
            <div>
              <div class="fw-semibold">Giao nhanh toàn quốc</div>
              <small class="text-muted">Nhận hàng & kiểm tra</small>
            </div>
          </div>
        </div>
        <div class="col-6">
          <div class="feature-tile">
            <i class="bi bi-arrow-repeat"></i>
            <div>
              <div class="fw-semibold">Đổi trả 7 ngày</div>
              <small class="text-muted">Linh hoạt – rõ ràng</small>
            </div>
          </div>
        </div>
        <div class="col-6">
          <div class="feature-tile">
            <i class="bi bi-telephone"></i>
            <div>
              <div class="fw-semibold">Hỗ trợ tận tâm</div>
              <small class="text-muted">Hotline & chat nhanh</small>
            </div>
          </div>
        </div>
      </div>

      <a href="<?= $base ?>?page=products" class="btn btn-primary mt-3">
        Khám phá sản phẩm
      </a>
    </div>
  </div>
</section>

<section class="container-xxl pb-5">
  <div class="row g-4 text-center">
    <div class="col-6 col-md-3">
      <div class="stat-item">
        <div class="stat-number">1,500+</div>
        <div class="stat-label">Sản phẩm</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-item">
        <div class="stat-number">4+</div>
        <div class="stat-label">Thương hiệu</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-item">
        <div class="stat-number">99%</div>
        <div class="stat-label">Khách hài lòng</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-item">
        <div class="stat-number">24/7</div>
        <div class="stat-label">Hỗ trợ</div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/partials/footer.php'; ?>
