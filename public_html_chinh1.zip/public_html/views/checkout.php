<?php
// checkout.php - updated to be compatible with router using $base and with direct access
// Place this file in the same folder as home.php/cart.php and partials

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Helper: escape output
if (!function_exists('e')) {
  function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}

// Helper to build a URL that ensures the `page` parameter is set to the desired value
function url_with_page($base, $pageValue = 'checkout') {
    // If $base is empty or not provided, fallback to current script
    if (empty($base)) {
        $base = basename($_SERVER['PHP_SELF']);
    }

    $parts = parse_url($base);

    $schemeHost = '';
    if (!empty($parts['scheme']) && !empty($parts['host'])) {
        $schemeHost = $parts['scheme'] . '://' . $parts['host'];
        if (!empty($parts['port'])) $schemeHost .= ':' . $parts['port'];
    }

    $path = $parts['path'] ?? ($parts['host'] ? '' : $base);
    parse_str($parts['query'] ?? '', $q);
    $q['page'] = $pageValue;
    $newQuery = http_build_query($q);

    return $schemeHost . $path . ($newQuery ? '?' . $newQuery : '');
}

// Determine $base if available (many projects set $base in header.php). If not, try to build from current script.
$base = isset($base) ? $base : (isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : 'index.php');

// Build checkout/process URLs using url_with_page so links work whether $base already has query params or not
$checkoutUrl = url_with_page($base, 'checkout');
$processUrl = url_with_page($base, 'checkout_process');

require_once __DIR__ . '/../models/Product.php'; // adjust path if your models are elsewhere

// CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}

$items = [];
$subtotal = 0.0;
if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $pid => $qty) {
        $p = Product::find((int)$pid);
        if ($p) {
            $p['qty'] = (int)$qty;
            $p['line_total'] = $p['qty'] * (float)$p['price'];
            $items[] = $p;
            $subtotal += $p['line_total'];
        }
    }
}

$taxRate = 0.00;
$shippingFee = 30000.0;
$tax = round($subtotal * $taxRate, 2);
$total = round($subtotal + $tax + ($subtotal > 0 ? $shippingFee : 0), 2);

// Include header (same pattern as home.php)
if (file_exists(__DIR__ . '/partials/header.php')) {
    include __DIR__ . '/partials/header.php';
} else if (file_exists(__DIR__ . '/../partials/header.php')) {
    include __DIR__ . '/../partials/header.php';
}
?>

<div class="container my-4">
  <div class="row">
    <div class="col-lg-7">
      <h3>Thông tin giao hàng</h3>
      <?php if (empty($items)): ?>
        <div class="alert alert-info">Giỏ hàng trống. <a href="<?= e(url_with_page($base, 'products')) ?>">Tiếp tục mua sắm</a></div>
      <?php else: ?>
        <form id="checkoutForm" method="post" action="<?= e($processUrl) ?>">
          <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

          <div class="mb-3">
            <label class="form-label">Họ và tên <span class="text-danger">*</span></label>
            <input name="fullname" type="text" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input name="email" type="email" class="form-control">
          </div>

          <div class="mb-3">
            <label class="form-label">Số điện thoại <span class="text-danger">*</span></label>
            <input name="phone" type="text" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Địa chỉ giao hàng <span class="text-danger">*</span></label>
            <textarea name="address" class="form-control" rows="2" required></textarea>
          </div>

          <div class="mb-3">
            <label class="form-label">Ghi chú</label>
            <textarea name="note" class="form-control" rows="2"></textarea>
          </div>

          <div class="mb-3">
            <label class="form-label">Phương thức thanh toán</label>
            <div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="payment_method" id="pm_cod" value="cod" checked>
                <label class="form-check-label" for="pm_cod">Thanh toán khi nhận hàng (COD)</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="payment_method" id="pm_transfer" value="bank_transfer">
                <label class="form-check-label" for="pm_transfer">Chuyển khoản ngân hàng</label>
              </div>
            </div>
          </div>

          <div class="d-flex justify-content-between align-items-center mt-4">
            <a href="<?= e(url_with_page($base, 'cart')) ?>" class="btn btn-secondary">Quay lại giỏ hàng</a>
            <button id="placeOrderBtn" type="submit" class="btn btn-success">Xác nhận & Thanh toán</button>
          </div>
        </form>
      <?php endif; ?>
    </div>

    <div class="col-lg-5">
      <h3>Đơn hàng</h3>
      <div class="card p-3">
        <?php if (empty($items)): ?>
          <div class="text-center text-muted">Không có sản phẩm</div>
        <?php else: ?>
        
        <?php
        $exchangeRate = 25000; // 1 USD = 25,000 VND
        ?>
        <?php
// Phí vận chuyển cố định
$shippingFee = 30.00;

// Tính thuế (nếu có)
$tax = isset($taxRate) && $taxRate > 0 ? $subtotal * $taxRate : 0;

// Tính tổng cộng
$total = $subtotal + $tax + $shippingFee;
?>

<?php foreach ($items as $it): ?>
  <div class="d-flex justify-content-between py-2 border-bottom">
    <div>
      <div class="fw-semibold"><?= e($it['name']) ?></div>
      <div class="text-muted small">x <?= (int)$it['qty'] ?></div>
    </div>
    <div>$<?= number_format($it['line_total'], 2, '.', ',') ?></div>
  </div>
<?php endforeach; ?>

<div class="py-2 d-flex justify-content-between">
  <div>Tạm tính</div>
  <div>$<?= number_format($subtotal, 2, '.', ',') ?></div>
</div>

<?php if (isset($taxRate) && $taxRate > 0): ?>
  <div class="py-2 d-flex justify-content-between">
    <div>Thuế (<?= ($taxRate * 100) ?>%)</div>
    <div>$<?= number_format($tax, 2, '.', ',') ?></div>
  </div>
<?php endif; ?>

<div class="py-2 d-flex justify-content-between">
  <div>Phí vận chuyển</div>
  <div>$<?= number_format($shippingFee, 2, '.', ',') ?></div>
</div>

<hr>

<div class="py-2 d-flex justify-content-between fw-bold fs-5">
  <div>Tổng cộng</div>
  <div>$<?= number_format($total, 2, '.', ',') ?></div>
</div>


        <?php endif; ?>
      </div>

    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  var placeBtn = document.getElementById('placeOrderBtn');
  if (!placeBtn) return;

  var hasItems = <?= empty($items) ? 'false' : 'true' ?>;
  if (!hasItems) {
    placeBtn.disabled = true;
  }

  var form = document.getElementById('checkoutForm');
  if (form) {
    form.addEventListener('submit', function (e) {
      var fullname = form.querySelector('[name="fullname"]');
      var phone = form.querySelector('[name="phone"]');
      var address = form.querySelector('[name="address"]');
      if (!fullname.value.trim() || !phone.value.trim() || !address.value.trim()) {
        e.preventDefault();
        alert('Vui lòng điền họ tên, số điện thoại và địa chỉ giao hàng.');
        return false;
      }
      // CSRF check on client is optional; server must validate
    });
  }
});
</script>

<?php
// Include footer
if (file_exists(__DIR__ . '/partials/footer.php')) {
    include __DIR__ . '/partials/footer.php';
} else if (file_exists(__DIR__ . '/../partials/footer.php')) {
    include __DIR__ . '/../partials/footer.php';
}
?>
