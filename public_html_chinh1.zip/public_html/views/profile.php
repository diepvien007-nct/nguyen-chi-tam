<?php
// Tệp này giả định bạn đã có session_start() từ index.php
// và đã được kiểm tra đăng nhập (require_login() trong index.php)

// --- BIẾN CẦN THIẾT ---
$message = null; // Để lưu thông báo thành công hoặc lỗi
$user = null; // Để lưu thông tin user
$userId = $_SESSION['user']['id'] ?? 0; // Lấy user ID từ session

// --- KẾT NỐI CSDL ---
// Đường dẫn đã được sửa dựa trên cấu trúc thư mục của bạn
require_once __DIR__ . '/../core/Database.php'; 
try {
    // SỬA LỖI LỚN NHẤT: Lấy đối tượng PDO bằng phương thức tĩnh Database::get()
    // Đối tượng $pdo bây giờ chính là đối tượng PDO đã kết nối.
    $pdo = Database::get(); 
    
    // Đặt chế độ báo lỗi cho PDO (KHÔNG CẦN NỮA VÌ ĐÃ CÓ TRONG Database::get())
    // Tuy nhiên, nếu muốn ghi đè, bạn có thể gọi:
    // $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 

} catch (Exception $e) {
    // Lỗi kết nối đã được xử lý trong Database::get(), nhưng giữ lại để bắt các Exception khác
    die("Không thể xử lý kết nối CSDL: " . $e->getMessage());
}


// --- XỬ LÝ CẬP NHẬT (NẾU LÀ POST REQUEST) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    
    // 1. Lấy dữ liệu an toàn
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    // 2. Xử lý upload ảnh (nếu có)
    $avatarPath = $_SESSION['user']['profile_image'] ?? null; // Giữ ảnh cũ làm mặc định
    
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $targetDir = "public/uploads/avatars/"; // Thư mục lưu ảnh 
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        
        $fileName = uniqid() . "_" . basename($_FILES['profile_image']['name']);
        $targetFile = $targetDir . $fileName;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Kiểm tra file ảnh
        $check = @getimagesize($_FILES['profile_image']['tmp_name']); 
        if ($check !== false) {
            // Chỉ cho phép vài định dạng
            if (in_array($imageFileType, ['jpg', 'png', 'jpeg', 'gif'])) {
                if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetFile)) {
                    $avatarPath = $targetFile; // Cập nhật đường dẫn ảnh mới
                    // Xóa ảnh cũ (nếu có và không phải ảnh mặc định)
                    $oldImage = $_SESSION['user']['profile_image'] ?? null;
                    if ($oldImage && $oldImage != $avatarPath && file_exists($oldImage)) {
                        @unlink($oldImage);
                    }
                } else {
                    $message = ['type' => 'danger', 'text' => 'Lỗi khi tải ảnh lên.'];
                }
            } else {
                $message = ['type' => 'warning', 'text' => 'Chỉ cho phép file JPG, JPEG, PNG & GIF.'];
            }
        } else {
            $message = ['type' => 'warning', 'text' => 'Tệp không phải là ảnh.'];
        }
    }

    // 3. Cập nhật CSDL (chỉ khi không có lỗi upload)
    if (empty($message)) {
        try {
            // SỬ DỤNG $pdo cho các lệnh SQL
            $sql = "UPDATE users SET fullname = :fullname, email = :email, phone = :phone, profile_image = :avatar WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':fullname' => $fullname,
                ':email' => $email,
                ':phone' => $phone,
                ':avatar' => $avatarPath,
                ':id' => $userId
            ]);

            $message = ['type' => 'success', 'text' => 'Cập nhật thông tin thành công!'];

            // Cập nhật lại session
            $_SESSION['user']['fullname'] = $fullname;
            $_SESSION['user']['email'] = $email;
            $_SESSION['user']['phone'] = $phone;
            $_SESSION['user']['profile_image'] = $avatarPath;
            // Cập nhật $_SESSION['user']['username'] nếu nó được dùng cho tên hiển thị
            $_SESSION['user']['username'] = $fullname; 

        } catch (PDOException $e) {
            $message = ['type' => 'danger', 'text' => 'Lỗi CSDL: ' . $e->getMessage()];
        }
    }
}


// --- LẤY THÔNG TIN USER ĐỂ HIỂN THỊ TRÊN FORM ---
// (Luôn truy vấn lại CSDL để đảm bảo dữ liệu mới nhất)
try {
    // SỬ DỤNG $pdo cho các lệnh SQL
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // Trường hợp hiếm: user bị xóa nhưng session còn
        die("Không tìm thấy người dùng.");
    }
    
    // Cập nhật session cho khớp (phòng trường hợp đăng nhập bằng session cũ)
    $_SESSION['user'] = $user;

} catch (PDOException $e) {
    die("Lỗi truy vấn người dùng: " . $e->getMessage());
}


// --- BAO GỒM HEADER ---
// (header.php cần $meta)
$meta = ['title' => 'Thông tin cá nhân'];
// Dựa vào cấu trúc thư mục của bạn, header.php nằm trong /views/partials/
require __DIR__ . '/partials/header.php'; 
?>

<div class="row justify-content-center">
    <div class="col-lg-8 col-md-10">
        <div class="card shadow-sm border-0 rounded-3">
            <div class="card-body p-4 p-md-5">

                <h2 class="card-title text-center fw-bold mb-4">Hồ sơ cá nhân</h2>

                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $message['type']; ?> alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($message['text']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="?page=profile" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="update_profile" value="1">

                    <div class="text-center mb-4">
                        <img id="avatarPreview" 
                             src="<?php echo htmlspecialchars($user['profile_image'] ?? 'https://placehold.co/150x150/E2E8F0/A0AEC0?text=Avatar'); ?>" 
                             alt="Ảnh đại diện" 
                             class="img-thumbnail rounded-circle" 
                             style="width: 150px; height: 150px; object-fit: cover;"
                             onerror="this.src='https://placehold.co/150x150/E2E8F0/A0AEC0?text=Avatar';">
                    </div>

                    <div class="mb-3">
                        <label for="profile_image" class="form-label">Thay đổi ảnh đại diện</label>
                        <input class="form-control" type="file" id="profile_image" name="profile_image" accept="image/*" onchange="previewImage(event)">
                        <div class="form-text">PNG, JPG, GIF (tối đa 2MB).</div>
                    </div>

                    <div class="mb-3">
                        <label for="fullname" class="form-label">Họ và tên</label>
                        <input type="text" class="form-control" id="fullname" name="fullname" 
                               value="<?php echo htmlspecialchars($user['fullname'] ?? ''); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="phone" class="form-label">Số điện thoại</label>
                        <input type="tel" class="form-control" id="phone" name="phone" 
                               value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tên đăng nhập</label>
                        <input type="text" class="form-control" 
                               value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" disabled readonly>
                        <div class="form-text">Bạn không thể thay đổi tên đăng nhập.</div>
                    </div>

                    <hr class="my-4">

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="bi bi-save me-2"></i> Lưu thay đổi
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function(){
            var output = document.getElementById('avatarPreview');
            output.src = reader.result;
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>

<?php
// --- BAO GỒM FOOTER ---
// Dựa vào cấu trúc thư mục của bạn, footer.php nằm trong /views/partials/
require __DIR__ . '/partials/footer.php'; 
?>