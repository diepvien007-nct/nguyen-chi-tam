<?php require __DIR__ . '/_guard.php'; ?>
<?php
require_once __DIR__ . '/../../core/Database.php';
$pdo = Database::get();

$notice = '';
$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

// Xử lý hành động
if ($id > 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    if ($action === 'approve') {
      $pdo->prepare("UPDATE comments SET status='approved' WHERE id=:id")->execute([':id'=>$id]);
      $notice = '<div class="alert alert-success">Đã duyệt bình luận.</div>';
    } elseif ($action === 'reject') {
      $pdo->prepare("UPDATE comments SET status='rejected' WHERE id=:id")->execute([':id'=>$id]);
      $notice = '<div class="alert alert-warning">Đã từ chối bình luận.</div>';
    } elseif ($action === 'delete') {
      $pdo->prepare("DELETE FROM comments WHERE id=:id")->execute([':id'=>$id]);
      $notice = '<div class="alert alert-danger">Đã xoá bình luận.</div>';
    }
  } catch (Throwable $e) {
    $notice = '<div class="alert alert-danger">Lỗi: '.htmlspecialchars($e->getMessage()).'</div>';
  }
}

// Lấy dữ liệu
$sql = "SELECT c.id, c.content, c.rating, c.status, c.created_at,
               COALESCE(u.username, c.guest_name) AS author,
               p.name AS product_name
        FROM comments c
        LEFT JOIN users u ON u.id = c.user_id
        LEFT JOIN products p ON p.id = c.product_id
        ORDER BY c.created_at DESC";
$rows = $pdo->query($sql)->fetchAll() ?: [];
?>
<?php include __DIR__ . '/partials/header_admin.php'; ?>

<h1 class="h5 mb-3"><i class="bi bi-chat-left-text"></i> Quản lý bình luận</h1>
<?= $notice ?>

<div class="card border-0 shadow-sm rounded-4">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr>
          <th>ID</th>
          <th>Sản phẩm</th>
          <th>Tác giả</th>
          <th>Nội dung</th>
          <th>Rating</th>
          <th>Trạng thái</th>
          <th>Ngày</th>
          <th class="text-end">Hành động</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td><small><?= htmlspecialchars($r['product_name'] ?? '') ?></small></td>
          <td><strong><?= htmlspecialchars($r['author'] ?? 'Khách') ?></strong></td>
          <td><?= nl2br(htmlspecialchars($r['content'])) ?></td>
          <td><?= (int)($r['rating'] ?? 0) ?>/5</td>
          <td>
            <?php if ($r['status']==='pending'): ?>
              <span class="badge bg-secondary">Chờ duyệt</span>
            <?php elseif ($r['status']==='approved'): ?>
              <span class="badge bg-success">Đã duyệt</span>
            <?php else: ?>
              <span class="badge bg-danger">Từ chối</span>
            <?php endif; ?>
          </td>
          <td><small class="text-muted"><?= $r['created_at'] ?></small></td>
          <td class="text-end">
            <div class="btn-group btn-group-sm">
              <?php if ($r['status']==='pending'): ?>
                <form method="post" action="?page=admin_comments&action=approve&id=<?= $r['id'] ?>">
                  <button class="btn btn-success" type="submit" title="Duyệt"><i class="bi bi-check"></i></button>
                </form>
                <form method="post" action="?page=admin_comments&action=reject&id=<?= $r['id'] ?>">
                  <button class="btn btn-warning" type="submit" title="Từ chối"><i class="bi bi-x-lg"></i></button>
                </form>
              <?php endif; ?>
              <form method="post" action="?page=admin_comments&action=delete&id=<?= $r['id'] ?>"
                    onsubmit="return confirm('Xoá bình luận này?');">
                <button class="btn btn-outline-danger" type="submit" title="Xoá"><i class="bi bi-trash"></i></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?>
          <tr><td colspan="8" class="text-center text-muted py-4">Chưa có bình luận nào</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/partials/footer_admin.php'; ?>
