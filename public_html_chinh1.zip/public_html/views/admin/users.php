<?php require __DIR__ . '/_guard.php'; ?>
<?php
require_once __DIR__ . '/../../core/Database.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$pdo = Database::get();
$notice = '';
$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

$currentUserId   = (int)($_SESSION['user']['id'] ?? 0);
$currentUserRole = $_SESSION['user']['role'] ?? 'user';

function count_admins(PDO $pdo): int {
  $st = $pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'");
  return (int)$st->fetchColumn();
}

/* ====== HANDLE ACTIONS (POST) ====== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    if ($action === 'set_role' && $id > 0) {
      $newRole = $_POST['role'] ?? 'user';
      if (!in_array($newRole, ['user','admin'], true)) throw new RuntimeException('Role không hợp lệ.');

      // role hiện tại của user mục tiêu
      $st = $pdo->prepare("SELECT role FROM users WHERE id=:id");
      $st->execute([':id'=>$id]);
      $oldRole = $st->fetchColumn();

      // không cho tự hạ quyền mình
      if ($id === $currentUserId && $currentUserRole === 'admin' && $newRole !== 'admin') {
        throw new RuntimeException('Không thể tự hạ quyền của chính bạn.');
      }
      // không cho làm mất admin cuối cùng
      if ($oldRole === 'admin' && $newRole === 'user' && count_admins($pdo) <= 1) {
        throw new RuntimeException('Không thể hạ quyền admin cuối cùng.');
      }

      $u = $pdo->prepare("UPDATE users SET role=:r WHERE id=:id");
      $u->execute([':r'=>$newRole, ':id'=>$id]);
      $notice = '<div class="alert alert-success">Đã cập nhật quyền.</div>';
    }

    if ($action === 'delete' && $id > 0) {
      if ($id === $currentUserId) throw new RuntimeException('Bạn không thể tự xoá tài khoản của mình.');

      $st = $pdo->prepare("SELECT role FROM users WHERE id=:id");
      $st->execute([':id'=>$id]);
      $role = $st->fetchColumn();
      if ($role === 'admin' && count_admins($pdo) <= 1) {
        throw new RuntimeException('Không thể xoá admin cuối cùng.');
      }

      $pdo->prepare("DELETE FROM users WHERE id=:id")->execute([':id'=>$id]);
      $notice = '<div class="alert alert-danger">Đã xoá tài khoản.</div>';
    }
  } catch (Throwable $e) {
    $notice = '<div class="alert alert-danger">Lỗi: '.htmlspecialchars($e->getMessage()).'</div>';
  }
}

/* ====== DATA ====== */
$q = trim($_GET['q'] ?? '');
$where = ''; $params = [];
if ($q !== '') { $where = "WHERE username LIKE :q OR email LIKE :q"; $params[':q'] = '%'.$q.'%'; }

$st = $pdo->prepare("SELECT id, username, email, role, created_at FROM users $where ORDER BY id DESC");
foreach ($params as $k=>$v) $st->bindValue($k,$v);
$st->execute();
$rows = $st->fetchAll() ?: [];
?>
<?php include __DIR__ . '/partials/header_admin.php'; ?>

<h1 class="h5 mb-3"><i class="bi bi-people"></i> Users</h1>
<?= $notice ?>

<form class="row g-2 mb-3" method="get">
  <input type="hidden" name="page" value="admin_users">
  <div class="col-sm-8 col-md-6 col-lg-4">
    <div class="input-group">
      <span class="input-group-text"><i class="bi bi-search"></i></span>
      <input class="form-control" name="q" placeholder="Tìm username hoặc email" value="<?= htmlspecialchars($q) ?>">
    </div>
  </div>
  <div class="col-sm-4 col-md-2">
    <button class="btn btn-outline-primary w-100">Tìm</button>
  </div>
</form>

<div class="card border-0 shadow-sm rounded-4">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Email</th>
          <th>Role</th>
          <th>Created</th>
          <th class="text-end" style="width:140px">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $u): ?>
        <tr>
          <td><?= (int)$u['id'] ?></td>
          <td><strong><?= htmlspecialchars($u['username']) ?></strong></td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td>
            <?php if ($u['role'] === 'admin'): ?>
              <span class="badge bg-success">admin</span>
            <?php else: ?>
              <span class="badge bg-secondary">user</span>
            <?php endif; ?>
          </td>
          <td><small class="text-muted"><?= htmlspecialchars($u['created_at']) ?></small></td>
          <td class="text-end">
            <div class="btn-group btn-group-sm">
              <!-- Nút đổi quyền: user ⇄ admin -->
              <form method="post" action="?page=admin_users&action=set_role&id=<?= (int)$u['id'] ?>">
                <input type="hidden" name="role" value="<?= $u['role']==='admin' ? 'user' : 'admin' ?>">
                <button class="btn btn-outline-primary" type="submit"
                        title="Đổi sang <?= $u['role']==='admin' ? 'user' : 'admin' ?>"
                        <?= ($u['id']===$currentUserId && $u['role']==='admin') ? 'disabled' : '' ?>>
                  <i class="bi bi-shuffle"></i>
                </button>
              </form>

              <!-- Nút xoá -->
              <form method="post" action="?page=admin_users&action=delete&id=<?= (int)$u['id'] ?>"
                    onsubmit="return confirm('Xoá tài khoản này?');">
                <button class="btn btn-outline-danger" type="submit"
                        <?= ($u['id']===$currentUserId) ? 'disabled' : '' ?>>
                  <i class="bi bi-trash"></i>
                </button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">Không có người dùng.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/partials/footer_admin.php'; ?>
