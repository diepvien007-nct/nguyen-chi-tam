<?php require __DIR__ . '/_guard.php'; ?>
<?php
require_once __DIR__ . '/../../core/Database.php';
$pdo = Database::get();

$q      = trim($_GET['q'] ?? '');
$p      = max(1, (int)($_GET['p'] ?? 1));
$per    = 10;
$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);
$notice = '';

// categories for select
$cats = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll() ?: [];

// CRUD (không CSRF)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (($action==='create') || ($action==='edit' && $id>0)) {
    $category_id = (int)($_POST['category_id'] ?? 0);
    $name        = trim($_POST['name'] ?? '');
    $slug        = trim($_POST['slug'] ?? '');
    $sku         = trim($_POST['sku'] ?? '');
    $price       = (float)($_POST['price'] ?? 0);
    $stock       = (int)($_POST['stock'] ?? 0);
    $image_url   = trim($_POST['image_url'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if ($category_id<=0 || $name==='' || $slug==='') {
      $notice = '<div class="alert alert-danger">Vui lòng nhập đủ Category, Name, Slug.</div>';
    } else {
      try {
        if ($action==='create') {
          $sql = "INSERT INTO products (category_id,name,slug,sku,price,stock,image_url,description)
                  VALUES (:cid,:n,:s,:sku,:p,:st,:img,:d)";
          $stmt = $pdo->prepare($sql);
          $stmt->execute([
            ':cid'=>$category_id, ':n'=>$name, ':s'=>$slug, ':sku'=>$sku?:null,
            ':p'=>$price, ':st'=>$stock, ':img'=>$image_url?:null, ':d'=>$description?:null
          ]);
          $notice = '<div class="alert alert-success">Đã thêm sản phẩm.</div>';
        } else {
          $sql = "UPDATE products SET category_id=:cid, name=:n, slug=:s, sku=:sku,
                  price=:p, stock=:st, image_url=:img, description=:d
                  WHERE id=:id";
          $stmt = $pdo->prepare($sql);
          $stmt->execute([
            ':cid'=>$category_id, ':n'=>$name, ':s'=>$slug, ':sku'=>$sku?:null,
            ':p'=>$price, ':st'=>$stock, ':img'=>$image_url?:null, ':d'=>$description?:null,
            ':id'=>$id
          ]);
          $notice = '<div class="alert alert-success">Đã cập nhật sản phẩm.</div>';
        }
      } catch (Throwable $e) {
        $notice = '<div class="alert alert-danger">Lỗi: '.htmlspecialchars($e->getMessage()).'</div>';
      }
    }
  }

  if ($action==='delete' && $id>0) {
    try {
      $stmt = $pdo->prepare("DELETE FROM products WHERE id=:id");
      $stmt->execute([':id'=>$id]);
      $notice = '<div class="alert alert-success">Đã xoá sản phẩm.</div>';
    } catch (Throwable $e) {
      $notice = '<div class="alert alert-danger">Không thể xoá sản phẩm này.</div>';
    }
  }
}

// data (search + pagination)
$where  = '';
$params = [];
if ($q !== '') {
  $where = "WHERE p.name LIKE :q OR p.sku LIKE :q";
  $params[':q'] = '%'.$q.'%';
}
$stmt = $pdo->prepare("SELECT COUNT(*) FROM products p $where");
$stmt->execute($params);
$total = (int)$stmt->fetchColumn();
$pages = max(1, (int)ceil($total/$per));
if ($p > $pages) $p = $pages;
$offset = ($p-1)*$per;

$sql = "SELECT p.id, p.name, p.price, p.sku, p.stock, p.created_at, p.image_url, p.slug,
               p.category_id, c.name AS category_name, p.description
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        $where
        ORDER BY p.id DESC
        LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);
foreach ($params as $k=>$v) $stmt->bindValue($k,$v);
$stmt->bindValue(':limit',$per,PDO::PARAM_INT);
$stmt->bindValue(':offset',$offset,PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll() ?: [];

// edit row
$editRow = null;
if ($action==='edit' && $id>0) {
  $s = $pdo->prepare("SELECT * FROM products WHERE id=:id");
  $s->execute([':id'=>$id]);
  $editRow = $s->fetch();
}
?>
<?php include __DIR__ . '/partials/header_admin.php'; ?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h5 mb-0"><i class="bi bi-box-seam me-2"></i>Products</h1>
  <a href="?page=admin_products&action=create" class="btn btn-primary">
    <i class="bi bi-plus-circle me-1"></i> Thêm
  </a>
</div>

<?= $notice ?>

<!-- FORM: create/edit -->
<?php if ($action==='create' || ($action==='edit' && $editRow)): ?>
<div class="card border-0 shadow-sm rounded-4 mb-3">
  <div class="card-body">
    <h2 class="h6 mb-3"><?= $action==='create'?'Thêm sản phẩm':'Sửa sản phẩm' ?></h2>
    <form method="post" action="?page=admin_products&action=<?= $action ?><?= $editRow ? '&id='.(int)$editRow['id'] : '' ?>">
      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Danh mục</label>
          <select name="category_id" class="form-select" required>
            <option value="">-- Chọn danh mục --</option>
            <?php foreach ($cats as $c): ?>
              <option value="<?= (int)$c['id'] ?>"
                <?= (int)($editRow['category_id'] ?? 0) === (int)$c['id'] ? 'selected':'' ?>>
                <?= htmlspecialchars($c['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-5">
          <label class="form-label">Tên sản phẩm</label>
          <input class="form-control" name="name" required
                 value="<?= htmlspecialchars($editRow['name'] ?? '') ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Slug</label>
          <input class="form-control" name="slug" required
                 value="<?= htmlspecialchars($editRow['slug'] ?? '') ?>">
        </div>

        <div class="col-md-3">
          <label class="form-label">SKU</label>
          <input class="form-control" name="sku"
                 value="<?= htmlspecialchars($editRow['sku'] ?? '') ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Giá</label>
          <input type="number" step="0.01" min="0" class="form-control" name="price" required
                 value="<?= htmlspecialchars($editRow['price'] ?? '0') ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Tồn kho</label>
          <input type="number" min="0" class="form-control" name="stock" required
                 value="<?= htmlspecialchars($editRow['stock'] ?? '0') ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Ảnh (URL)</label>
          <input class="form-control" name="image_url"
                 value="<?= htmlspecialchars($editRow['image_url'] ?? '') ?>">
        </div>

        <div class="col-12">
          <label class="form-label">Mô tả</label>
          <textarea class="form-control" name="description" rows="4"><?= htmlspecialchars($editRow['description'] ?? '') ?></textarea>
        </div>
      </div>

      <div class="d-flex gap-2 mt-3">
        <button class="btn btn-primary" type="submit">
          <i class="bi bi-check2-circle me-1"></i> Lưu
        </button>
        <a class="btn btn-outline-secondary" href="?page=admin_products">Hủy</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- FILTER -->
<form class="row g-2 mb-3" method="get">
  <input type="hidden" name="page" value="admin_products">
  <div class="col-sm-8 col-md-6 col-lg-5">
    <div class="input-group">
      <span class="input-group-text"><i class="bi bi-search"></i></span>
      <input class="form-control" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Tìm theo tên hoặc SKU">
    </div>
  </div>
  <div class="col-sm-4 col-md-3 col-lg-2">
    <button class="btn btn-outline-primary w-100">Tìm</button>
  </div>
</form>

<!-- TABLE -->
<div class="card border-0 shadow-sm rounded-4">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr>
          <th>ID</th><th>Name</th><th>Category</th><th>SKU</th>
          <th class="text-end">Price</th><th class="text-end">Stock</th>
          <th>Created</th><th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td>
            <div class="d-flex align-items-center gap-2">
              <?php if (!empty($r['image_url'])): ?>
                <img src="<?= htmlspecialchars($r['image_url']) ?>" alt="" style="width:40px;height:40px;object-fit:cover;border-radius:8px;">
              <?php endif; ?>
              <div><?= htmlspecialchars($r['name']) ?></div>
            </div>
          </td>
          <td><?= htmlspecialchars($r['category_name'] ?? '') ?></td>
          <td><code><?= htmlspecialchars($r['sku'] ?? '') ?></code></td>
          <td class="text-end">$<?= number_format((float)$r['price'],2) ?></td>
          <td class="text-end"><?= (int)$r['stock'] ?></td>
          <td><small class="text-muted"><?= htmlspecialchars($r['created_at']) ?></small></td>
          <td class="text-end">
            <div class="btn-group btn-group-sm">
              <a class="btn btn-outline-secondary"
                 href="?page=admin_products&action=edit&id=<?= (int)$r['id'] ?>">
                 <i class="bi bi-pencil-square"></i>
              </a>
              <form method="post"
                    action="?page=admin_products&action=delete&id=<?= (int)$r['id'] ?>"
                    onsubmit="return confirm('Xóa sản phẩm này?');">
                <button class="btn btn-outline-danger" type="submit">
                  <i class="bi bi-trash"></i>
                </button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?>
        <tr><td colspan="8" class="text-center text-muted py-4">Không có dữ liệu</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if ($pages>1): ?>
<nav class="mt-3">
  <ul class="pagination">
    <?php for($i=1;$i<=$pages;$i++):
      $params = $_GET; $params['page']='admin_products'; $params['p']=$i; $url='?'.http_build_query($params); ?>
      <li class="page-item <?= $i===$p?'active':'' ?>"><a class="page-link" href="<?= $url ?>"><?= $i ?></a></li>
    <?php endfor; ?>
  </ul>
</nav>
<?php endif; ?>

<?php include __DIR__ . '/partials/footer_admin.php'; ?>
