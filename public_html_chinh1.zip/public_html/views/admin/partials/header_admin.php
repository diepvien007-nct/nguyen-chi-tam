<?php
require_once __DIR__ . '/../../../app/config.php';

// Lấy BASE_URL từ hằng số
$base = rtrim(BASE_URL, '/') . '/';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
?>

<?php include __DIR__ . '/../../partials/header.php'; ?>

<div class="row g-3">
  <aside class="col-12 col-lg-3">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="card-body p-0">
        <div class="list-group list-group-flush">
          <a class="list-group-item list-group-item-action <?= ($_GET['page']??'')==='admin_dashboard'?'active':'' ?>" href="<?= $base ?>?page=admin_dashboard">
            <i class="bi bi-speedometer2 me-2"></i> Dashboard
          </a>
          <a class="list-group-item list-group-item-action <?= ($_GET['page']??'')==='admin_products'?'active':'' ?>" href="<?= $base ?>?page=admin_products">
            <i class="bi bi-box-seam me-2"></i> Products
          </a>
          <a class="list-group-item list-group-item-action <?= ($_GET['page']??'')==='admin_categories'?'active':'' ?>" href="<?= $base ?>?page=admin_categories">
            <i class="bi bi-tags me-2"></i> Categories
          </a>
          <a class="list-group-item list-group-item-action <?= ($_GET['page']??'')==='admin_users'?'active':'' ?>" href="<?= $base ?>?page=admin_users">
            <i class="bi bi-people me-2"></i> Users
          </a>
          <a class="list-group-item list-group-item-action <?= ($_GET['page']??'')==='admin_comments'?'active':'' ?>" href="<?= $base ?>?page=admin_comments">
            <i class="bi bi-chat-dots me-2"></i> Comments
          </a>
        </div>
      </div>
    </div>
  </aside>
  <section class="col-12 col-lg-9">
