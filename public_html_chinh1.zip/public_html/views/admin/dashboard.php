<?php require __DIR__ . '/_guard.php'; ?>
<?php
require_once __DIR__ . '/../../core/Database.php';
$pdo = Database::get();

$counts = [
  'products'   => (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn(),
  'categories' => (int)$pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn(),
  'users'      => (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
  'comments'   => (int)$pdo->query("SELECT COUNT(*) FROM comments")->fetchColumn(),
];
?>
<?php include __DIR__ . '/partials/header_admin.php'; ?>

<h1 class="h4 mb-3 d-flex align-items-center gap-2">
  <i class="bi bi-speedometer2"></i> Tổng quan
</h1>

<div class="row g-3">
  <div class="col-6 col-md-3">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="card-body text-center">
        <div class="fs-2 fw-bold"><?= $counts['products'] ?></div>
        <div class="text-muted">Products</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="card-body text-center">
        <div class="fs-2 fw-bold"><?= $counts['categories'] ?></div>
        <div class="text-muted">Categories</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="card-body text-center">
        <div class="fs-2 fw-bold"><?= $counts['users'] ?></div>
        <div class="text-muted">Users</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="card-body text-center">
        <div class="fs-2 fw-bold"><?= $counts['comments'] ?></div>
        <div class="text-muted">Comments</div>
      </div>
    </div>
  </div>
</div>

<hr class="my-4">

<?php
require_once __DIR__ . '/../../core/Logger.php';
$logs = Logger::latest(8);
?>

<div class="card border-0 shadow-sm rounded-4">
  <div class="card-body">
    <h2 class="h6 mb-3">Hoạt động gần đây</h2>
    <?php if ($logs): ?>
      <ul class="list-group list-group-flush">
        <?php foreach ($logs as $log): ?>
          <li class="list-group-item">
            <div class="d-flex justify-content-between">
              <strong><?= htmlspecialchars($log['username'] ?? 'Hệ thống') ?></strong>
              <small class="text-muted"><?= htmlspecialchars($log['created_at']) ?></small>
            </div>
            <div><?= htmlspecialchars($log['message']) ?></div>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <div class="text-muted">Chưa có hoạt động nào.</div>
    <?php endif; ?>
  </div>
</div>


<?php include __DIR__ . '/partials/footer_admin.php'; ?>
