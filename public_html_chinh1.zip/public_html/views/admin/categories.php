<?php require __DIR__ . '/_guard.php'; ?>
<?php
require_once __DIR__ . '/../../core/Database.php';
$pdo = Database::get();

$notice = '';
$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

// CREATE / UPDATE / DELETE 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (($action === 'create') || ($action === 'edit' && $id>0)) {
    $name = trim($_POST['name'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    if ($name === '' || $slug === '') {
      $notice = '<div class="alert alert-danger">Vui lòng nhập đủ Name và Slug.</div>';
    } else {
      try {
        if ($action === 'create') {
          $stmt = $pdo->prepare("INSERT INTO categories (name, slug) VALUES (:n, :s)");
          $stmt->execute([':n'=>$name, ':s'=>$slug]);
          $notice = '<div class="alert alert-success">Đã thêm danh mục.</div>';
        } else {
          $stmt = $pdo->prepare("UPDATE categories SET name=:n, slug=:s WHERE id=:id");
          $stmt->execute([':n'=>$name, ':s'=>$slug, ':id'=>$id]);
          $notice = '<div class="alert alert-success">Đã cập nhật danh mục.</div>';
        }
      } catch (Throwable $e) {
        $notice = '<div class="alert alert-danger">Lỗi: '.htmlspecialchars($e->getMessage()).'</div>';
      }
    }
  }

  if ($action === 'delete' && $id>0) {
    try {
      $stmt = $pdo->prepare("DELETE FROM categories WHERE id=:id");
      $stmt->execute([':id'=>$id]);
      $notice = '<div class="alert alert-success">Đã xoá danh mục.</div>';
    } catch (Throwable $e) {
      $notice = '<div class="alert alert-danger">Không thể xoá. Có thể còn sản phẩm thuộc danh mục này.</div>';
    }
  }
}

// DATA
$editRow = null;
if ($action === 'edit' && $id>0) {
  $s = $pdo->prepare("SELECT id, name, slug FROM categories WHERE id=:id");
  $s->execute([':id'=>$id]);
  $editRow = $s->fetch();
}
$rows = $pdo->query("SELECT id, name, slug, created_at FROM categories ORDER BY name")->fetchAll() ?: [];
?>
<?php include __DIR__ . '/partials/header_admin.php'; ?>

<h1 class="h5 mb-3 d-flex align-items-center gap-2"><i class="bi bi-tags"></i> Categories</h1>
<?= $notice ?>

<div class="row g-3">
  <!-- Form -->
  <div class="col-12 col-lg-5">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="card-body">
        <h2 class="h6 mb-3"><?= $editRow ? 'Sửa danh mục' : 'Thêm danh mục' ?></h2>
        <form method="post" action="?page=admin_categories<?= $editRow ? '&action=edit&id='.(int)$editRow['id'] : '&action=create' ?>">
          <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" name="name" class="form-control" required
                   value="<?= htmlspecialchars($editRow['name'] ?? '') ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Slug</label>
            <input type="text" name="slug" class="form-control" required
                   value="<?= htmlspecialchars($editRow['slug'] ?? '') ?>">
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-primary" type="submit">
              <i class="bi bi-check2-circle me-1"></i> <?= $editRow ? 'Cập nhật' : 'Thêm mới' ?>
            </button>
            <?php if ($editRow): ?>
              <a class="btn btn-outline-secondary" href="?page=admin_categories">Hủy</a>
            <?php endif; ?>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Table -->
  <div class="col-12 col-lg-7">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
            <tr><th>ID</th><th>Name</th><th>Slug</th><th>Created</th><th class="text-end">Actions</th></tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $r): ?>
            <tr>
              <td><?= (int)$r['id'] ?></td>
              <td><?= htmlspecialchars($r['name']) ?></td>
              <td><code><?= htmlspecialchars($r['slug']) ?></code></td>
              <td><small class="text-muted"><?= htmlspecialchars($r['created_at']) ?></small></td>
              <td class="text-end">
                <div class="btn-group btn-group-sm">
                  <a class="btn btn-outline-secondary"
                     href="?page=admin_categories&action=edit&id=<?= (int)$r['id'] ?>">
                    <i class="bi bi-pencil-square"></i>
                  </a>
                  <form method="post" action="?page=admin_categories&action=delete&id=<?= (int)$r['id'] ?>"
                        onsubmit="return confirm('Xóa danh mục này?');">
                    <button class="btn btn-outline-danger" type="submit">
                      <i class="bi bi-trash"></i>
                    </button>
                  </form>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?>
              <tr><td colspan="5" class="text-center text-muted py-4">Không có dữ liệu</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/partials/footer_admin.php'; ?>
