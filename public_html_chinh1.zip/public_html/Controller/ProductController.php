<?php
require_once __DIR__ . '/../models/Product.php';

class ProductController {
    public function detail($id) {
        $id = (int)$id;
        if ($id <= 0) {
            http_response_code(400);
            echo "ID không hợp lệ.";
            return;
        }

        try {
            $product = Product::find($id);
        } catch (Throwable $e) {
            error_log('[Product detail] ' . $e->getMessage());
            http_response_code(500);
            echo "Có lỗi xảy ra.";
            return;
        }

        if (!$product) {
            http_response_code(404);
            echo "❌ Sản phẩm không tồn tại.";
            return;
        }

        // Truyền $product sang view
        require __DIR__ . '/../views/product_detail.php';
    }
}
